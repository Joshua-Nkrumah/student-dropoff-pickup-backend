﻿using System;
namespace cleverchap_montessori.Payloads.Request.Delegate
{
	public class SingleDelegate
    {
        public string? DelegateId { get; set; }
    }
}

