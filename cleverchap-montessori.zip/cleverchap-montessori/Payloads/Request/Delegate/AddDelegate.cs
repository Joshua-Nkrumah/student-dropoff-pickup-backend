﻿using System;
namespace cleverchap_montessori.Payloads.Request.Delegate
{
	public class AddDelegate
    {
        public string? StudentId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? EmailAddress { get; set; }
        public string? PhoneNumber { get; set; }
        public string? RelationshipToChild { get; set; }
        public string? CreatedBy { get; set; }
    }
}

