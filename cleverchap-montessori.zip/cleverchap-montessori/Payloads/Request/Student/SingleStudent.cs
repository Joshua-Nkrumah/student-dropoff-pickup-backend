﻿using System;
namespace cleverchap_montessori.Payloads.Request.Student
{
	public class SingleStudent
	{
        public string? StudentId { get; set; }
    }
}

