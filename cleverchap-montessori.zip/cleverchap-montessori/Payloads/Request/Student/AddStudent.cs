﻿using System;
namespace cleverchap_montessori.Payloads.Request.Student
{
	public class AddStudent
	{
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? DateOfBirth { get; set; }
        public string? Gender { get; set; }
        public string? EmergencyContact { get; set; }
        public string? Location { get; set; }
        public string? Nationality { get; set; }
        public string? MedicalConditions { get; set; }
        public string? CreatedBy { get; set; }
    }
}

