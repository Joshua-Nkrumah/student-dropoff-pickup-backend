﻿using System;
namespace cleverchap_montessori.Payloads.Request.Parent
{
	public class SingleParent
	{
        public string? ParentId { get; set; }
    }
}

