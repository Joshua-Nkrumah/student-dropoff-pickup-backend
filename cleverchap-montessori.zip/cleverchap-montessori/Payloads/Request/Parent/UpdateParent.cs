﻿using System;
namespace cleverchap_montessori.Payloads.Request.Parent
{
	public class UpdateParent
	{
        public string? ParentId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Location { get; set; }
        public string? Nationality { get; set; }
        public string? EmailAddress { get; set; }
        public string? Address { get; set; }
        public string? Type { get; set; }
        public string? PhoneNumber { get; set; }
        public string? CreatedBy { get; set; }
        public string? Status { get; set; }

    }
}

