﻿using System;
namespace cleverchap_montessori.Payloads.Request.Teacher
{
	public class UpdateTeacher
	{
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? EmailAddress { get; set; }
        public string? PhoneNumber { get; set; }
        public string? CreatedBy { get; set; }
    }
}

