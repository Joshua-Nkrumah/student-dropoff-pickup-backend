﻿using System;
namespace cleverchap_montessori.Payloads.Request.Teacher
{
	public class SingleTeacher
    {
        public string? TeacherId { get; set; }
    }
}

