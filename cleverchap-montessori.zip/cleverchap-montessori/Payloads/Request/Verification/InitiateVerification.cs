﻿using System;
namespace cleverchap_montessori.Payloads.Request.Verification
{
	public class InitiateVerification
    {
        public string? Email { get; set; }
        public string? Name { get; set; }
        public string? Phone { get; set; }
    }
}

