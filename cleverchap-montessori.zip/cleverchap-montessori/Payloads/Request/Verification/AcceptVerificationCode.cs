﻿using System;
namespace cleverchap_montessori.Payloads.Request.Verification
{
	public class AcceptVerificationCode
    {
        public string? LogId { get; set; }
        public string? VerificationId { get; set; }
        public string? EnteredOTP { get; set; }
        public string? ActivityType { get; set; }
        public string? AuthorizedName { get; set; }
        public string? ClassId { get; set; }
        public string? ParentId { get; set; }
        public string? DelegateId { get; set; }
        public string? CreatedBy { get; set; }
        public string? StudentId { get; set; }
        public string? Relation { get; set; }
        

    }
}

