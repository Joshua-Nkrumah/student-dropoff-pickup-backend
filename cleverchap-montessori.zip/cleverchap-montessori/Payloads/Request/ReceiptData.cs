﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class ReceiptData
	{
        public string? SenderEmail { get; set; }
        public string? SenderName { get; set; }
        public string? Subject { get; set; }
        public string? Description { get; set; }
        public decimal? Amount { get; set; }
        public decimal? TotalAmount { get; set; }
        public string? Date { get; set; }
        public string? ReceiptId { get; set; }
    }
}

