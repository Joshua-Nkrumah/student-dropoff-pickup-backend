﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class MailData
	{
        public string? SenderEmail { get; set; }
        public string? SenderName { get; set; }
        public string? EmailSubject { get; set; }
        public string? EmailBody { get; set; }
    }
}

