﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class SingleMember
	{
		public string? MemberID { get; set; }
		
	}
}

