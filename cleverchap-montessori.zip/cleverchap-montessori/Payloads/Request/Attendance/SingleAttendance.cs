﻿using System;
namespace cleverchap_montessori.Payloads.Request.Attendance
{
	public class SingleAttendance
    {
        public string? LogId { get; set; }
    }
}

