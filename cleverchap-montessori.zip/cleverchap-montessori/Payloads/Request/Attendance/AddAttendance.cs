﻿using System;
namespace cleverchap_montessori.Payloads.Request.Attendance
{
	public class AddAttendance
    {
        public string? StudentId { get; set; }
        public string? ParentId { get; set; }
        public string? DelegateId { get; set; }
        public string? ClassId { get; set; }
        public string? ActivityType { get; set; }
        public string? AuthorizedName { get; set; }
        public string? Relation { get; set; }
        public string? Remarks { get; set; }
        public string? CreatedBy { get; set; }
    }
}

