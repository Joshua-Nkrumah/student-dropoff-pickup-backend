﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class UpdateDonation
	{
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? DonationStatus { get; set; }
        public string? CreatedBy { get; set; }
        public string? Remarks { get; set; }
        public DateTime DonationDate { get; set; }
    }
}

