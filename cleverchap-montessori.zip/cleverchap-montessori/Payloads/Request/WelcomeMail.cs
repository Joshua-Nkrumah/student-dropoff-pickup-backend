﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class WelcomeMail
	{
        public string? Name { get; set; }
        public string? Email { get; set; }
    }
}

