﻿using System;
namespace cleverchap_montessori.Payloads.Request.Class
{
	public class SingleClass
    {
        public string? ClassId { get; set; }
    }
}

