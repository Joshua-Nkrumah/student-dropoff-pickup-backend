﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class SingleContribution
	{
        public string? ContributionID { get; set; }
        public string? MemberID { get; set; }
    }
}

