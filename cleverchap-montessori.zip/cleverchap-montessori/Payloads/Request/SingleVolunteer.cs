﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class SingleVolunteer
	{
		public string? VolunteerID { get; set; }
		
	}
}

