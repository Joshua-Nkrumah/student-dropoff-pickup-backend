﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class SingleDonation
	{
        public string? DonationID { get; set; }
        public string? MemberID { get; set; }
    }
}

