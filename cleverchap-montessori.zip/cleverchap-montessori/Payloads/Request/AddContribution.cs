﻿using System;
namespace cleverchap_montessori.Payloads.Request
{
	public class AddContribution
	{
        public string? MemberId { get; set; }
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? ContributionStatus { get; set; }
        public string? CreatedBy { get; set; }
        public string? Remarks { get; set; }
    }
}

