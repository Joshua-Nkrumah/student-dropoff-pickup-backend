﻿using System;
namespace cleverchap_montessori.Payloads.Response
{
	public class InitiateVerificationResponse
	{
		public string? VerificationId { get; set; }
		public string? LogId { get; set; }
	}
}

