﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace cleverchap_montessori.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedMember1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Location",
                table: "Members",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Location",
                table: "Members");
        }
    }
}
