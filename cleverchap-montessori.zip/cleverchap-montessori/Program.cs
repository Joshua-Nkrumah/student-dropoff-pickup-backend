﻿using Microsoft.AspNetCore.Identity;
using cleverchap_montessori.Context;
using cleverchap_montessori.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using cleverchap_montessori.Services.Interfaces;
using MailKit;
using cleverchap_montessori.Models.Auth;
using Microsoft.Extensions.Options;

//try
//{
var builder = WebApplication.CreateBuilder(args);

// Add services to the container.      
builder.Services.AddDbContext<AuthDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetSection("ConnectionStrings:DefaultConnection").Value);
});

//builder.Services.AddDbContext<OccwelfareDbContext>(options =>
//{
//    options.UseSqlServer(builder.Configuration.GetSection("ConnectionStrings:DefaultConnection").Value);
//});
builder.Services.AddDbContext<CcmontessoriDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetSection("ConnectionStrings:DefaultConnection").Value);
});

builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequiredLength = 5;

}).AddEntityFrameworkStores<AuthDbContext>()
    .AddDefaultTokenProviders();


builder.Services.Configure<IdentityOptions>(opts =>
{
    opts.User.RequireUniqueEmail = true;
});

//builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
//{
//    options.Password.RequiredLength = 5;
//}).AddEntityFrameworkStores<AuthDbContext>()
//        .AddDefaultTokenProviders();

//builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options => options.SignIn.RequireConfirmedAccount = true)
//    .AddEntityFrameworkStores<AuthDbContext>();

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidateActor = true,
        ValidateIssuer = true,
        ValidateAudience = true,
        RequireExpirationTime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration.GetSection("Jwt:Issuer").Value,
        ValidAudience = builder.Configuration.GetSection("Jwt:Audience").Value,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration.GetSection("Jwt:Key").Value))
    };
}
    );


//var AllowSpecificOrigins = "AllowSpecificOrigins";
var AllowEverything = "AllowEverything";

builder.Services.AddCors(options =>
{
    //options.AddPolicy(AllowSpecificOrigins, // This is the open house we talked about!
    //    builder =>
    //    {
    //        builder.WithOrigins("http://localhost:9001")
    //        .AllowAnyHeader()
    //        .AllowAnyMethod();
    //        //builder.AllowAnyOrigin() // Any origin is welcome...
    //        //    .AllowAnyHeader() // With any type of headers...
    //        //    .AllowAnyMethod(); // And any HTTP methods. Such a jolly party indeed!
    //    });

    options.AddPolicy(AllowEverything, // This is the open house we talked about!
           builder =>
           {
               builder.AllowAnyOrigin() // Any origin is welcome...
                   .AllowAnyHeader() // With any type of headers...
                   .AllowAnyMethod(); // And any HTTP methods. Such a jolly party indeed!
           });
});


builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IStudentService, StudentService>();
builder.Services.AddScoped<IParentService, ParentService>();
builder.Services.AddScoped<IDelegateService, DelegateService>();
builder.Services.AddScoped<IVerificationService, VerificationService>();
builder.Services.AddScoped<IAttendanceService, AttendanceService>();
builder.Services.AddScoped<IMailerService, MailerService>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();


app.MapControllers();


app.UseCors(AllowEverything);
//app.UseCors();
app.Run();

//}
//catch (Exception ex)
//{
//    var result = new
//    {
//        status = "03",
//        message = "Application failed while running",
//        data = "" ?? ex.Message
//    };
//    Console.WriteLine(result);
//}





