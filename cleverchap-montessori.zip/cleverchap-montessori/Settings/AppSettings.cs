﻿using System;
namespace cleverchap_montessori.Settings
{

    public partial class AppSettings
    {
        public virtual ConnectionStrings? ConnectionStrings { get; set; }
        public virtual Logging? Logging { get; set; }
        public virtual Jwt? Jwt { get; set; }
        public virtual MailSettings? MailSettings { get; set; }
        public virtual string? AllowedHosts { get; set; }
    }

    public partial class ConnectionStrings
    {
        public virtual string? DefaultConnection { get; set; }
    }

    public partial class Jwt
    {
        public virtual string? Key { get; set; }
        public virtual Uri? Issuer { get; set; }
        public virtual Uri? Audience { get; set; }
    }

    public partial class Logging
    {
        public virtual LogLevel? LogLevel { get; set; }
    }

    public partial class LogLevel
    {
        public virtual string? Default { get; set; }
        public virtual string? MicrosoftAspNetCore { get; set; }
    }

    public partial class MailSettings
    {
        public virtual string? Server { get; set; }
        public virtual long? Port { get; set; }
        public virtual string? SenderName { get; set; }
        public virtual string? SenderEmail { get; set; }
        public virtual string? UserName { get; set; }
        public virtual string? Password { get; set; }
    }
}
