﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Parent;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface IParentService
    {
        Task<GeneralResponsePayload> CreateParentAsync(AddParent Parent);
        Task<GeneralResponsePayload> GetParentByIdAsync(SingleParent id);
        Task<GeneralResponsePayload> GetAllParentsAsync();
        Task<GeneralResponsePayload> UpdateParentAsync(UpdateParent Parent);
        Task<GeneralResponsePayload> DeleteParentAsync(SingleParent id);
        Task<GeneralResponsePayload> SoftDeleteParentAsync(SingleParent id); // Soft delete method
        Task<GeneralResponsePayload> GetParentYearSummaryAsync(RecordsByMonthDto Parent);
    }
}

