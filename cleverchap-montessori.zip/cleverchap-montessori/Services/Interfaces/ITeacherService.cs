﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Payloads.Request.Teacher;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface ITeacherService
    {
        Task<GeneralResponsePayload> CreateTeacherAsync(AddTeacher Teacher);
        Task<GeneralResponsePayload> GetTeacherByIdAsync(SingleTeacher id);
        Task<GeneralResponsePayload> GetAllTeachersAsync();
        Task<GeneralResponsePayload> UpdateTeacherAsync(UpdateTeacher Teacher);
        Task<GeneralResponsePayload> DeleteTeacherAsync(SingleTeacher id);
        Task<GeneralResponsePayload> SoftDeleteTeacherAsync(SingleTeacher id); // Soft delete method
        Task<GeneralResponsePayload> GetTeacherYearSummaryAsync(RecordsByMonthDto Teacher);
    }
}

