﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Class;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface IClassService
    {
        Task<GeneralResponsePayload> CreateClassAsync(AddClass Class);
        Task<GeneralResponsePayload> GetClassByIdAsync(SingleClass id);
        Task<GeneralResponsePayload> GetAllClasssAsync();
        Task<GeneralResponsePayload> UpdateClassAsync(UpdateClass Class);
        Task<GeneralResponsePayload> DeleteClassAsync(SingleClass id);
        Task<GeneralResponsePayload> SoftDeleteClassAsync(SingleClass id); // Soft delete method
        Task<GeneralResponsePayload> GetClassYearSummaryAsync(RecordsByMonthDto Class);
    }
}

