﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface IAttendanceService
    {
        Task<GeneralResponsePayload> GetAllAttendancesAsync();
        Task<GeneralResponsePayload> GetAttendanceYearSummaryAsync(RecordsByMonthDto Attendance);
    }
}

