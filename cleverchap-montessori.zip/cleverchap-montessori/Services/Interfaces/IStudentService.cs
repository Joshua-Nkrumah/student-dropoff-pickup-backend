﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Student;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface IStudentService
    {
        Task<GeneralResponsePayload> CreateStudentAsync(AddStudent Student);
        Task<GeneralResponsePayload> GetStudentByIdAsync(SingleStudent id);
        Task<GeneralResponsePayload> GetAllStudentsAsync();
        Task<GeneralResponsePayload> UpdateStudentAsync(UpdateStudent Student);
        Task<GeneralResponsePayload> DeleteStudentAsync(SingleStudent id);
        Task<GeneralResponsePayload> SoftDeleteStudentAsync(SingleStudent id); // Soft delete method
        Task<GeneralResponsePayload> GetStudentYearSummaryAsync(RecordsByMonthDto Student);
    }
}

 