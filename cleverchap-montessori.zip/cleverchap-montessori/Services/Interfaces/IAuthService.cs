﻿using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using cleverchap_montessori.Models;
using cleverchap_montessori.Models.Auth;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface IAuthService
    {
        TokenResponse GenerateAccessToken(LoginUser user);
        Task<bool> Login(LoginUser user);
        //Task<IdentityResult> RegisterUser(LoginUser user);
        Task<IdentityResult> RegisterUser(RegisterUser user);
        Task<IdentityResult> RegisterUserWithGeneratedPassword(RegisterUserOnly user);
        Task<IdentityResult> ResetPassword(ResetPassword user);
        Task<IdentityResult> ChangePassword(PasswordChange user);
        Task<GeneralResponsePayload> GetAllRoles();
        Task<GeneralResponsePayload> CreateRole();
        Task<GeneralResponsePayload> UserRoles(UserRole user);
        Task<GeneralResponsePayload> AllUsers();
        Task<IdentityResult> AssignUserToRole(AssignUserToRole user);
        Task<UserList> UserResource(LoginUser user);
        Task<IdentityResult> RemoveUserFromRole(AssignUserToRole user);
        Task<IdentityResult> ChangeUserRole(ChangeUserRole user);
    }
}

