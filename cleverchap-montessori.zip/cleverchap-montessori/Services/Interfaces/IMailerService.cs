﻿using System;
using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;

namespace cleverchap_montessori.Services.Interfaces
{
	public interface IMailerService
	{
        Task<GeneralResponsePayload> SendSimpleMailAsync(MailData mailData);
        Task<GeneralResponsePayload> SendHTMLMailAsync(MailData mailData);
        Task<GeneralResponsePayload> SendHTMLReciptMailAsync(ReceiptData mailData);
    }
}

