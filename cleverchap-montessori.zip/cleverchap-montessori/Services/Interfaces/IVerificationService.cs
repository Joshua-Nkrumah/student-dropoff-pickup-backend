﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Payloads.Request.Verification;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface IVerificationService
    {
        Task<GeneralResponsePayload> VerifyCodeAsync(AcceptVerificationCode Code);
        Task<GeneralResponsePayload> GenerateCodeAsync(InitiateVerification Verification);
    }
}

