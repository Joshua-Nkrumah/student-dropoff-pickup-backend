﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Delegate;

namespace cleverchap_montessori.Services.Interfaces
{
    public interface IDelegateService
    {
        Task<GeneralResponsePayload> CreateDelegateAsync(AddDelegate Delegate);
        Task<GeneralResponsePayload> GetDelegateByIdAsync(SingleDelegate id);
        Task<GeneralResponsePayload> GetAllDelegatesAsync();
        Task<GeneralResponsePayload> UpdateDelegateAsync(UpdateDelegate Delegate);
        Task<GeneralResponsePayload> DeleteDelegateAsync(SingleDelegate id);
        Task<GeneralResponsePayload> SoftDeleteDelegateAsync(SingleDelegate id); // Soft delete method
        Task<GeneralResponsePayload> GetDelegateYearSummaryAsync(RecordsByMonthDto Delegate);
    }
}

