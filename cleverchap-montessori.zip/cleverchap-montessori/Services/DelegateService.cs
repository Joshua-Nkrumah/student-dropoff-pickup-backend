﻿
using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Context;
using cleverchap_montessori.Models;
using Microsoft.EntityFrameworkCore;
using cleverchap_montessori.Payloads.Request.Delegate;
using cleverchap_montessori.Entities;


namespace cleverchap_montessori.Services
{
    public class DelegateService : IDelegateService
    {
        private readonly IConfiguration _config;
        protected readonly CcmontessoriDbContext _db;
        protected readonly ILogger<DelegateService> _logger;

        public DelegateService(IConfiguration config, CcmontessoriDbContext db, ILogger<DelegateService> logger)
        {
            _config = config;
            _logger = logger;
            _db = db;
        }

        public static Guid GenerateDelegateId()
        {
            // Generate a GUID
            Guid guid = Guid.NewGuid();
            // Get the first 5 digits of the GUID
            string shortGuid = guid.ToString().Substring(0, 7);
            // Combine with the prefix
            string prefixedGuid = "CCM" + shortGuid.ToUpper();
            return Guid.Parse(prefixedGuid);
        }


        //public async Task<GeneralResponsePayload> GetAllDelegatesAsync()
        //{
        //    try
        //    {
        //        var delegates = await _db.AuthorizedDelegates.OrderByDescending(m => m.CreatedAt).ToListAsync();

        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Delegates retrieved successfully",
        //            Data = new RecordsList
        //            {
        //                Total = delegates.Count(),
        //                Records = delegates
        //            }
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "02",
        //            Message = "Could not retrieve delegates",
        //            Data = ex.Message
        //        };
        //    }
        //}

        public async Task<GeneralResponsePayload> GetAllDelegatesAsync()
        {
            try
            {
                var authorizedDelegates = await _db.AuthorizedDelegates.OrderByDescending(m => m.CreatedAt).ToListAsync();
                var details = (from authorizedDelegate in authorizedDelegates
                               join student in _db.Students
                              on authorizedDelegate.StudentId equals student.StudentId.ToString()
                               select new
                               {
                                   authorizedDelegate,
                                   student
                               }).ToList();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Delegates retrieved successfully",
                    Data = new RecordsList
                    {
                        Total = details.Count(),
                        Records = details
                    }
                };

            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve delegates",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> CreateDelegateAsync(AddDelegate Delegate)
        {
            try
            {
                _logger.LogInformation($"Adding only delegate: {Delegate.FirstName} {Delegate.LastName}");
                var now = DateTime.UtcNow;
                var delegateId = Guid.NewGuid();

                var delegate_ = new AuthorizedDelegate()
                {
                    FirstName = Delegate.FirstName,
                    LastName = Delegate.LastName,
                    CreatedAt = now,
                    CreatedBy = Delegate.CreatedBy,
                    DelegateId = delegateId,
                    UpdatedAt = now,
                    Email = Delegate.EmailAddress ?? "",
                    Phone = Delegate.PhoneNumber,
                    RelationshipToChild = Delegate.RelationshipToChild,
                    StudentId = Delegate.StudentId,
                    Status = "Active"

                };

                _db.Add(delegate_);
                await _db.SaveChangesAsync();
                _logger.LogInformation($"New Delegate Added: {Delegate.FirstName} {Delegate.LastName}");
                var result = new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Delegate added successfully",
                    Data = delegate_
                };

                return result;

            }
            catch (Exception ex)
            {
                var result = new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not add new delegate",
                    Data = ex.Message
                };

                return result;
            }
        }



        public async Task<GeneralResponsePayload> GetDelegateByIdAsync(SingleDelegate Delegate)
        {
            try
            {
                var existingDelegate = await _db.AuthorizedDelegates.FindAsync(Delegate.DelegateId);

                if (existingDelegate == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Delegate not found",
                        Data = null
                    };
                }

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Delegate retrieved successfully",
                    Data = existingDelegate
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve delegate",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> UpdateDelegateAsync(UpdateDelegate Delegate)
        {
            _logger.LogInformation($"Adding only delegate: {Delegate.FirstName} {Delegate.LastName}");
            var now = DateTime.UtcNow;
            try
            {
                var existingDelegate = await _db.AuthorizedDelegates.FindAsync(Delegate.DelegateId);

                if (existingDelegate == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Delegate not found",
                        Data = null
                    };
                }

                _logger.LogInformation($"Updating delegate: {existingDelegate.FirstName} {existingDelegate.LastName}");

                existingDelegate.FirstName = Delegate.FirstName;
                existingDelegate.LastName = Delegate.LastName;
                existingDelegate.Phone = Delegate.PhoneNumber;
                existingDelegate.Email = Delegate.EmailAddress;
                existingDelegate.RelationshipToChild = Delegate.RelationshipToChild;
                existingDelegate.UpdatedAt = now;
                existingDelegate.Status = Delegate.Status;
                existingDelegate.UpdatedAt = now;

                await _db.SaveChangesAsync();
                _logger.LogInformation($"Delegate updated: {existingDelegate.FirstName} {existingDelegate.LastName}");
                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Delegate updated successfully",
                    Data = existingDelegate
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not update delegate",
                    Data = ex.Message
                };
            }
        }



        public async Task<GeneralResponsePayload> DeleteDelegateAsync(SingleDelegate Delegate)
        {
            try
            {
                var existingDelegate = await _db.AuthorizedDelegates.FindAsync(Delegate.DelegateId);

                if (existingDelegate == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Delegate not found",
                        Data = null
                    };
                }

                _db.AuthorizedDelegates.Remove(existingDelegate);
                await _db.SaveChangesAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Delegate deleted successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not delete delegate",
                    Data = ex.Message
                };
            }
        }


        public async Task<GeneralResponsePayload> SoftDeleteDelegateAsync(SingleDelegate Delegate)
        {
            try
            {
                var existingDelegate = await _db.AuthorizedDelegates.FindAsync(Delegate.DelegateId);
                var now = DateTime.UtcNow;
                if (existingDelegate == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Delegate not found",
                        Data = null
                    };
                }

                existingDelegate.Status = "Deleted"; // Mark as deleted or move to trash
                existingDelegate.UpdatedAt = now;
                await _db.SaveChangesAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Delegate marked as deleted",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not soft-delete delegate",
                    Data = ex.Message
                };
            }
        }



        public async Task<GeneralResponsePayload> GetDelegateYearSummaryAsync(RecordsByMonthDto yearFilter)
        {
            try
            {
                var query = await _db.AuthorizedDelegates
               .Where(m => m.CreatedAt!.Value!.Year == yearFilter.Year)
               .GroupBy(m => new { m.CreatedAt!.Value!.Year, m.CreatedAt!.Value!.Month })
               .Select(group => new RecordsByMonthDto
               {
                   Year = group.Key.Year,
                   Month = group.Key.Month,
                   TotalRecords = group.Count()
               }).ToListAsync();

                var result = new GeneralResponsePayload
                {
                    Status = "00",
                    Message = $"Delegate summary for {yearFilter!.Year}",
                    Data = new RecordsList
                    {
                        Total = query.Count(),
                        Records = query
                    }
                };

                return result;
            }
            catch (Exception ex)
            {

                var result = new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve delegate yearly summary",
                    Data = ex.Message
                };

                return result;

            }
        }










    }
}

