﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace cleverchap_montessori.Files.MailTemplates
{
	public class WelcomeMailModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
