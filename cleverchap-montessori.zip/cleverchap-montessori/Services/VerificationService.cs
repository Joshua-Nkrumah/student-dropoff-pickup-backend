﻿using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Context;
using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Payloads.Request.Verification;
using cleverchap_montessori.Entities;
using cleverchap_montessori.Payloads.Response;

namespace cleverchap_montessori.Services
{
    public class VerificationService : IVerificationService
    {
        private readonly IConfiguration _config;
        protected readonly CcmontessoriDbContext _db;
        protected readonly ILogger<VerificationService> _logger;
        private readonly IMailerService _mailerService;


        public VerificationService(IConfiguration config, CcmontessoriDbContext db, ILogger<VerificationService> logger, IMailerService mailerService)
        {
            _config = config;
            _logger = logger;
            _db = db;
            _mailerService = mailerService;
        }

       public async Task<GeneralResponsePayload> VerifyCodeAsync(AcceptVerificationCode Code)
        {
            try
            {
                var now = DateTime.Now;
                var verification = _db.Verifications
                    //.Where(v => v.LogId == Code.LogId && v.Status == "Pending" && v.ExpiryTime >= now)
                    .Where(v => v.LogId == Code.LogId && v.Status == "Pending")
                    .FirstOrDefault();

                if (verification != null && verification.Otp == Code.EnteredOTP && now < verification.ExpiryTime  )
                {
                    verification.Status = "Verified";
                    _db.SaveChanges();

                    // Log the pickup or dropoff in the PickupDropoffLog table
                    var logEntry = new PickupDropoffLog
                    {
                        LogId = Guid.Parse(Code?.LogId),
                        ActivityType = Code.ActivityType,
                        AuthorizedDateTime = now,
                        AuthorizedName = Code.AuthorizedName,
                        ClassId = Code.ClassId,
                        DelegateId = Code.DelegateId,
                        ParentId = Code.ParentId,
                        CreatedAt = now,
                        CreatedBy = Code.CreatedBy,
                        Relation = Code.Relation,
                        Remarks = "",
                        Status = "Verified",
                        StudentId = Code.StudentId,
                        UpdatedAt = now,
                        // Set other fields...
                    };

                    _db.PickupDropoffLogs.Add(logEntry);
                    _db.SaveChanges();

                    return new GeneralResponsePayload
                    {
                        Status = "00",
                        Message = "Verification successful",
                        Data = logEntry
                    };
                    // OTP matched and accepted successfully
                }

                if (verification != null && verification.Otp == Code.EnteredOTP && verification?.ExpiryTime >= now)
                {

                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "OTP Expired",
                        Data = null
                    };
                }

                return new GeneralResponsePayload
                {
                    Status = "01",
                    Message = "Verification Failed",
                    Data = null
                };

                // OTP validation failed or OTP expired
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not verify OTP",
                    Data = null
                };
            }
        }

        public async Task<GeneralResponsePayload> GenerateCodeAsync(InitiateVerification Verification)
        {
            try
            {
                var otp = GenerateOTP();
                // Send OTP via Mail

                var mailerInfo = new MailData
                {
                    EmailBody = $"Below is the One-Time Password (OTP) you will need to complete the verification process:\n\nOTP: {otp}\n\nPlease use this OTP within the next 10 minutes to verify your identity during the pickup or dropoff process. If you did not initiate this verification, please contact our support team immediately.\n\n",
                    EmailSubject = "Cleverchap Montessori - Verification OTP",
                    SenderEmail = Verification.Email,
                    SenderName = Verification.Name,
                };

                var mailResult = await _mailerService.SendSimpleMailAsync(mailerInfo);

                if(mailResult.Status != "00")
                {

                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Failed to Send OTP",
                        Data = null
                    };
                }
                //

                var expiryTime = DateTime.Now.AddMinutes(10); // Set OTP expiry time (e.g., 10 minutes)
                var verificationId = Guid.NewGuid();
                var logId = Guid.NewGuid();

                var verification = new Verification
                {
                    VerificationId = verificationId,
                    LogId = logId.ToString(),
                    Otp = otp,
                    ExpiryTime = expiryTime,
                    Status = "Pending"

                };

                _db.Verifications.Add(verification);
                _db.SaveChanges();

                var response = new InitiateVerificationResponse()
                {
                    LogId = verification.LogId.ToString(),
                    VerificationId = verification.VerificationId.ToString()
                };

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Code generated and sent successfully",
                    Data = response
                };
            }
            catch (Exception ex)
            {

                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Student not found",
                    Data = ex.Message
                };

            }
        }

        public string GenerateOTP()
        {
            const int otpLength = 6;
            var random = new Random();
            var otp = new string(Enumerable.Range(0, otpLength).Select(_ => random.Next(10).ToString()[0]).ToArray());
            return otp;
        }

    }
}

