﻿using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Context;
using cleverchap_montessori.Models;
using Microsoft.EntityFrameworkCore;

namespace cleverchap_montessori.Services
{
    public class AttendanceService : IAttendanceService
    {
        private readonly IConfiguration _config;
        protected readonly CcmontessoriDbContext _db;
        protected readonly ILogger<AttendanceService> _logger;

        public AttendanceService(IConfiguration config, CcmontessoriDbContext db, ILogger<AttendanceService> logger)
        {
            _config = config;
            _logger = logger;
            _db = db;
        }

        public async Task<GeneralResponsePayload> GetAllAttendancesAsync()
        {
            try
            {
                var attendance = await _db.PickupDropoffLogs.OrderByDescending(m => m.CreatedAt).ToListAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Attendace retrieved successfully",
                    Data = new RecordsList
                    {
                        Total = attendance.Count(),
                        Records = attendance
                    }
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve attendance",
                    Data = ex.Message
                };
            }
        }


        public async Task<GeneralResponsePayload> GetAttendanceYearSummaryAsync(RecordsByMonthDto yearFilter)
        {
            try
            {
                var query = await _db.Students
               .Where(m => m.CreatedAt!.Value!.Year == yearFilter.Year)
               .GroupBy(m => new { m.CreatedAt!.Value!.Year, m.CreatedAt!.Value!.Month })
               .Select(group => new RecordsByMonthDto
               {
                   Year = group.Key.Year,
                   Month = group.Key.Month,
                   TotalRecords = group.Count()
               }).ToListAsync();

                var result = new GeneralResponsePayload
                {
                    Status = "00",
                    Message = $"Attendance summary for {yearFilter!.Year}",
                    Data = new RecordsList
                    {
                        Total = query.Count(),
                        Records = query
                    }
                };

                return result;
            }
            catch (Exception ex)
            {

                var result = new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve attendance yearly summary",
                    Data = ex.Message
                };

                return result;

            }
        }

    }
}

