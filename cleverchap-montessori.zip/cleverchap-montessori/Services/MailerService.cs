﻿
using System;
using MailKit.Net.Smtp;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MimeKit;
using cleverchap_montessori.Models;
using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Settings;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Shared;
using RazorEngineCore;
using System.Text;
using MailKit.Security;
using System.Runtime;
using System.Collections.Generic;

namespace cleverchap_montessori.Services
{
	public class MailerService: IMailerService
	{
        //private readonly AppSettings _config;

        static MailSettings _config = HelperFunction.GetAppSettingsData()?.MailSettings;

        //public MailerService(IOptions<AppSettings> appSettings)
        //{
        //    _config = appSettings.Value;
        //}

        public async Task<GeneralResponsePayload> SendSimpleMailAsync(MailData mailData)
        {
            try
            {
                Console.WriteLine(_config);
                //var mailData = new MailData();
                using (MimeMessage emailMessage = new MimeMessage())
                {
                    MailboxAddress emailFrom = new MailboxAddress(_config?.SenderName, _config?.SenderEmail);
                    emailMessage.From.Add(emailFrom);
                    MailboxAddress emailTo = new MailboxAddress(mailData.SenderName, mailData.SenderEmail);
                    emailMessage.To.Add(emailTo);

                    //emailMessage.Cc.Add(new MailboxAddress("Cc Receiver", "cc@example.com"));
                    //emailMessage.Bcc.Add(new MailboxAddress("Bcc Receiver", "bcc@example.com"));

                    emailMessage.Subject = mailData.EmailSubject;

                    BodyBuilder emailBodyBuilder = new BodyBuilder();
                    emailBodyBuilder.TextBody = mailData.EmailBody;

                    emailMessage.Body = emailBodyBuilder.ToMessageBody();
                    //this is the SmtpClient from the Mailkit.Net.Smtp namespace, not the System.Net.Mail one
                    using (SmtpClient mailClient = new SmtpClient())
                    {
                        mailClient.Connect(_config?.Server, (int)(_config?.Port), MailKit.Security.SecureSocketOptions.SslOnConnect);
                        //mailClient.Connect("live.smtp.mailtrap.io", 587, false);
                        mailClient.Authenticate(_config?.UserName, _config?.Password);
                        mailClient.Send(emailMessage);
                        mailClient.Disconnect(true);
                    }
                }
                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Email sent successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "01",
                    Message = "Could not send email",
                    Data = ex.Message
                };
            }
        }

         public async Task<GeneralResponsePayload> SendHTMLMailAsync(MailData mailData)
         {
            try
            {
                Console.WriteLine(_config);

                //var htmlbody = GetEmailTemplate("ReceiptMail", mailData);

                using (MimeMessage emailMessage = new MimeMessage())
                {
                    MailboxAddress emailFrom = new MailboxAddress(_config?.SenderName, _config?.SenderEmail);
                    emailMessage.From.Add(emailFrom);
                    MailboxAddress emailTo = new MailboxAddress(mailData.SenderName, mailData.SenderEmail);
                    emailMessage.To.Add(emailTo);

                    emailMessage.Subject = mailData.EmailSubject;

                    BodyBuilder emailBodyBuilder = new BodyBuilder();


                    //emailBodyBuilder.HtmlBody = htmlbody;

                    emailMessage.Body = emailBodyBuilder.ToMessageBody();

                    //this is the SmtpClient from the Mailkit.Net.Smtp namespace, not the System.Net.Mail one
                    using (SmtpClient mailClient = new SmtpClient())
                    {
                        mailClient.Connect(_config?.Server, (int)(_config?.Port), MailKit.Security.SecureSocketOptions.SslOnConnect);
                        //mailClient.Connect("live.smtp.mailtrap.io", 587, false);
                        mailClient.Authenticate(_config?.UserName, _config?.Password);
                        mailClient.Send(emailMessage);
                        mailClient.Disconnect(true);
                    }
                }
                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Email sent successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "01",
                    Message = "Could not send email",
                    Data = ex.Message
                };
            }
         }

        //public async Task<bool> SendAsync(MailData mailData, CancellationToken ct = default)
        //{
        //    try
        //    {
        //        // Initialize a new instance of the MimeKit.MimeMessage class
        //        var mail = new MimeMessage();

        //        #region Sender / Receiver
        //        // Sender
        //        mail.From.Add(new MailboxAddress(_settings.DisplayName, mailData.From ?? _settings.From));
        //        mail.Sender = new MailboxAddress(mailData.DisplayName ?? _settings.DisplayName, mailData.From ?? _settings.From);

        //        // Receiver
        //        foreach (string mailAddress in mailData.To)
        //            mail.To.Add(MailboxAddress.Parse(mailAddress));

        //        // Set Reply to if specified in mail data
        //        if (!string.IsNullOrEmpty(mailData.ReplyTo))
        //            mail.ReplyTo.Add(new MailboxAddress(mailData.ReplyToName, mailData.ReplyTo));

        //        // BCC
        //        // Check if a BCC was supplied in the request
        //        if (mailData.Bcc != null)
        //        {
        //            // Get only addresses where value is not null or with whitespace. x = value of address
        //            foreach (string mailAddress in mailData.Bcc.Where(x => !string.IsNullOrWhiteSpace(x)))
        //                mail.Bcc.Add(MailboxAddress.Parse(mailAddress.Trim()));
        //        }

        //        // CC
        //        // Check if a CC address was supplied in the request
        //        if (mailData.Cc != null)
        //        {
        //            foreach (string mailAddress in mailData.Cc.Where(x => !string.IsNullOrWhiteSpace(x)))
        //                mail.Cc.Add(MailboxAddress.Parse(mailAddress.Trim()));
        //        }
        //        #endregion

        //        #region Content

        //        // Add Content to Mime Message
        //        var body = new BodyBuilder();
        //        mail.Subject = mailData.Subject;
        //        body.HtmlBody = mailData.Body;
        //        mail.Body = body.ToMessageBody();

        //        #endregion

        //        #region Send Mail

        //        using var smtp = new SmtpClient();

        //        if (_settings.UseSSL)
        //        {
        //            await smtp.ConnectAsync(_settings.Host, _settings.Port, SecureSocketOptions.SslOnConnect, ct);
        //        }
        //        else if (_settings.UseStartTls)
        //        {
        //            await smtp.ConnectAsync(_settings.Host, _settings.Port, SecureSocketOptions.StartTls, ct);
        //        }

        //        await smtp.AuthenticateAsync(_settings.UserName, _settings.Password, ct);
        //        await smtp.SendAsync(mail, ct);
        //        await smtp.DisconnectAsync(true, ct);

        //        return true;
        //        #endregion

        //    }
        //    catch (Exception)
        //    {
        //        return false;
        //    }
        //}

        public string GetEmailTemplate(string emailTemplate, ReceiptData emailTemplateModel)
        {
            string mailTemplate = LoadTemplate(emailTemplate, emailTemplateModel);

            //string formattedMessage = string.Format(mailTemplate, emailTemplateModel.EmailToName, emailTemplateModel.EmailToId);

            IRazorEngine razorEngine = new RazorEngine();
            IRazorEngineCompiledTemplate modifiedMailTemplate = razorEngine.Compile(mailTemplate);
            
            return modifiedMailTemplate.Run(emailTemplateModel);
        }

        public string LoadTemplate(string emailTemplate, ReceiptData emailTemplateModel)
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string templateDir = Path.Combine(baseDir, "Files/MailTemplates");
            string templatePath = Path.Combine(templateDir, $"{emailTemplate}.cshtml");

            using FileStream fileStream = new FileStream(templatePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            using StreamReader streamReader = new StreamReader(fileStream, Encoding.Default);

            string mailTemplate = streamReader.ReadToEnd();
            mailTemplate = mailTemplate.Replace("[name]", emailTemplateModel.SenderName);
            mailTemplate = mailTemplate.Replace("[email]", emailTemplateModel.SenderEmail);
            mailTemplate = mailTemplate.Replace("[amount]", emailTemplateModel.Amount.ToString());
            mailTemplate = mailTemplate.Replace("[totalAmount]", emailTemplateModel.Amount.ToString());
            mailTemplate = mailTemplate.Replace("[description]", emailTemplateModel.Description);
            mailTemplate = mailTemplate.Replace("[date]", emailTemplateModel.Date);
            mailTemplate = mailTemplate.Replace("[receiptId]", emailTemplateModel.ReceiptId);
            

            streamReader.Close();

            return mailTemplate;
        }

        public async Task<GeneralResponsePayload> SendHTMLReciptMailAsync(ReceiptData mailData)
        {
            try
            {
                Console.WriteLine(_config);

                var htmlbody = GetEmailTemplate("ReceiptMail", mailData);

                using (MimeMessage emailMessage = new MimeMessage())
                {
                    MailboxAddress emailFrom = new MailboxAddress(_config?.SenderName, _config?.SenderEmail);
                    emailMessage.From.Add(emailFrom);
                    MailboxAddress emailTo = new MailboxAddress(mailData.SenderName, mailData.SenderEmail);
                    emailMessage.To.Add(emailTo);

                    emailMessage.Subject = mailData.Subject;

                    BodyBuilder emailBodyBuilder = new BodyBuilder();


                    emailBodyBuilder.HtmlBody = htmlbody;

                    emailMessage.Body = emailBodyBuilder.ToMessageBody();

                    //this is the SmtpClient from the Mailkit.Net.Smtp namespace, not the System.Net.Mail one
                    using (SmtpClient mailClient = new SmtpClient())
                    {
                        mailClient.Connect(_config?.Server, (int)(_config?.Port), MailKit.Security.SecureSocketOptions.SslOnConnect);
                        mailClient.Authenticate(_config?.UserName, _config?.Password);
                        mailClient.Send(emailMessage);
                        mailClient.Disconnect(true);
                    }
                }
                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Receipt sent successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "01",
                    Message = "Could not send receipt",
                    Data = ex.Message
                };

            }
        }
    }
}



