﻿using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Context;
using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Student;
using cleverchap_montessori.Entities;
using Microsoft.EntityFrameworkCore;

namespace cleverchap_montessori.Services
{
    public class StudentService : IStudentService
    {
        private readonly IConfiguration _config;
        protected readonly CcmontessoriDbContext _db;
        protected readonly ILogger<StudentService> _logger;

        public StudentService(IConfiguration config, CcmontessoriDbContext db, ILogger<StudentService> logger)
        {
            _config = config;
            _logger = logger;
            _db = db;
        }

        public static string GenerateStudentId()
        {
            // Generate a GUID
            Guid guid = Guid.NewGuid();
            // Get the first 5 digits of the GUID
            string shortGuid = guid.ToString().Substring(0, 7);
            // Combine with the prefix
            string prefixedGuid = "CCM" + shortGuid.ToUpper();
            return prefixedGuid;
        }

        public async Task<GeneralResponsePayload> CreateStudentAsync(AddStudent Student)
        {
            try
            {
                _logger.LogInformation($"Adding only student: {Student.FirstName} {Student.LastName}");
                var now = DateTime.UtcNow;
                var studentNumber = GenerateStudentId();
                var studentId = Guid.NewGuid();

                var student_ = new Student()
                {
                    FirstName = Student.FirstName,
                    LastName = Student.LastName,
                    EmergencyContact = Student.EmergencyContact ?? "",
                    CreatedAt = now,
                    CreatedBy = Student.CreatedBy,
                    DateOfBirth = Student.DateOfBirth,
                    Gender = Student.Gender,
                    StudentId = studentId,
                    ClassId = "",
                    MedicalConditions = Student.MedicalConditions,
                    Nationality = Student.Nationality,
                    UpdatedAt = now,
                    Location = Student.Location,
                    Status = "Active",
                    StudentNumber = studentNumber.ToString()
                };
                _db.Add(student_);
                await _db.SaveChangesAsync();
                _logger.LogInformation($"New Student Added: {Student.FirstName} {Student.LastName}");
                var result = new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Student added successfully",
                    Data = student_
                };

                return result;

            }
            catch (Exception ex)
            {
                var result = new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not add new student",
                    Data = ex.Message
                };

                return result;
            }
        }

        public async Task<GeneralResponsePayload> GetStudentByIdAsync(SingleStudent Student)
        {
            try
            {
                var existingStudent = await _db.Students.FindAsync(Student.StudentId);
                //var existingStudent = await _db.Students.FirstOrDefault(student => student.StudentId == Guid(Student.StudentId));
                if (existingStudent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Student not found",
                        Data = null
                    };
                }

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Student retrieved successfully",
                    Data = existingStudent
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve student",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> UpdateStudentAsync(UpdateStudent Student)
        {
            _logger.LogInformation($"Adding only student: {Student.FirstName} {Student.LastName}");
            var now = DateTime.UtcNow;
            try
            {
                //var existingStudent = await _db.Students.FirstOrDefaultAsync(student => student.StudentId == Student.StudentId);
                var existingStudent = await _db.Students.FindAsync(Guid.Parse(Student?.StudentId));

                if (existingStudent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Student not found",
                        Data = null
                    };
                }

                _logger.LogInformation($"Updating student: {existingStudent.FirstName} {existingStudent.LastName}");


                existingStudent.FirstName = Student.FirstName;
                existingStudent.LastName = Student.LastName;
                existingStudent.EmergencyContact = Student.EmergencyContact ?? "";
                existingStudent.DateOfBirth = Student.DateOfBirth;
                existingStudent.Gender = Student.Gender;
                //existingStudent.ClassId = "";
                existingStudent.MedicalConditions = "";
                existingStudent.Nationality = Student.Nationality;
                existingStudent.UpdatedAt = now;
                existingStudent.Location = Student.Location;
                existingStudent.Status = Student.Status;

                await _db.SaveChangesAsync();
                _logger.LogInformation($"Student updated: {existingStudent.FirstName} {existingStudent.LastName}");
                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Student updated successfully",
                    Data = existingStudent
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not update student",
                    Data = ex.Message
                };
            }
        }


        public async Task<GeneralResponsePayload> GetAllStudentsAsync()
        {
            try
            {
                var members = await _db.Students.OrderByDescending(m => m.CreatedAt).ToListAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Students retrieved successfully",
                    Data = new RecordsList
                    {
                        Total = members.Count(),
                        Records = members
                    }
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve students",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> DeleteStudentAsync(SingleStudent Student)
        {
            try
            {
                var existingStudent = await _db.Students.FindAsync(Student.StudentId);

                if (existingStudent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Student not found",
                        Data = null
                    };
                }

                _db.Students.Remove(existingStudent);
                await _db.SaveChangesAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Student deleted successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not delete student",
                    Data = ex.Message
                };
            }
        }


        public async Task<GeneralResponsePayload> SoftDeleteStudentAsync(SingleStudent Student)
        {
            try
            {
                var existingStudent = await _db.Students.FindAsync(Student.StudentId);
                var now = DateTime.UtcNow;

                //var existingStudent = await _db.Students.FirstOrDefaultAsync(student => student.StudentId == Guid.Parse(Student!.StudentId));
                if (existingStudent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Student not found",
                        Data = null
                    };
                }

                existingStudent.Status = "Deleted"; // Assuming you have a property like IsDeleted
                existingStudent.UpdatedAt = now;
                await _db.SaveChangesAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Student marked as deleted",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not soft-delete student",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> GetStudentYearSummaryAsync(RecordsByMonthDto yearFilter)
        {
            try
            {
                var query = await _db.Students
               .Where(m => m.CreatedAt!.Value!.Year == yearFilter.Year)
               .GroupBy(m => new { m.CreatedAt!.Value!.Year, m.CreatedAt!.Value!.Month })
               .Select(group => new RecordsByMonthDto
               {
                   Year = group.Key.Year,
                   Month = group.Key.Month,
                   TotalRecords = group.Count()
               }).ToListAsync();

                var result = new GeneralResponsePayload
                {
                    Status = "00",
                    Message = $"Student summary for {yearFilter!.Year}",
                    Data = new RecordsList
                    {
                        Total = query.Count(),
                        Records = query
                    }
                };

                return result;
            }
            catch (Exception ex)
            {

                var result = new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve student yearly summary",
                    Data = ex.Message
                };

                return result;

            }
        }


    }
}

