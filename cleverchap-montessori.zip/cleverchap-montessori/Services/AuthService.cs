﻿using System;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using System.Text;
using cleverchap_montessori.Models.Auth;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Shared;
using cleverchap_montessori.Context;
using cleverchap_montessori.Payloads.Request;
using Microsoft.Extensions.Logging;
using MailKit.Search;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using cleverchap_montessori.Models;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Azure;

namespace cleverchap_montessori.Services
{
    public class AuthService : IAuthService
    {
        private readonly UserManager<ApplicationUser> _userManager;

        private readonly IConfiguration _config;
        private readonly IMailerService _mailerService;
        protected readonly ILogger<AuthService> _logger;
        private readonly RoleManager<IdentityRole> _roleManager;

        public AuthService(UserManager<ApplicationUser> userManager, IConfiguration config, IMailerService mailerService,
            ILogger<AuthService> logger, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _config = config;
            _mailerService = mailerService;
            _logger = logger;
            _roleManager = roleManager;
        }

        public async Task<IdentityResult> RegisterUser(RegisterUser user)
        {
            // Split the email address to extract the username part before the "@" sign.
            var userName = user.Email.Split('@')[0];

            var identityUser = new ApplicationUser
            {
                UserName = userName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                FirstName = user.FirstName,
                LastName = user.LastName,
                EmailConfirmed = true, // Mark User as Enabled
                LockoutEnabled = true // Mark User as NOT Deleted

            };

            var result = await _userManager.CreateAsync(identityUser, user.Password);

            if (result.Succeeded != false)
            {
                var data = new AssignUserToRole
                {
                    Email = user.Email,
                    RoleName = "Security"
                };

                var result_ = await _userManager.AddToRoleAsync(identityUser, data.RoleName);

                if (result_.Succeeded)
                {

                    _logger.LogInformation($"User {user.Email} role has been assigned successfully during registration");
                }


            }
            return result;
        }

        public async Task<IdentityResult> RegisterUserWithGeneratedPassword(RegisterUserOnly user)
        {
            try
            {
                var userName = user.Email.Split('@')[0];

                var generatedPassword = PasswordGenerator.GeneratePassword();

                var identityUser = new ApplicationUser
                {
                    UserName = userName,
                    Email = user.Email,
                    PhoneNumber = user.PhoneNumber,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    EmailConfirmed = true, // Mark User as Enabled
                    LockoutEnabled = true // Mark User as NOT Deleted
                };

                var finalResult = new IdentityResult();

                var result = await _userManager.CreateAsync(identityUser, generatedPassword);
                bool containsPasswordError = result.Errors.Where(x => x.Code.StartsWith("Password")).Any();

                while (containsPasswordError == true)
                {
                    generatedPassword = PasswordGenerator.GeneratePassword();
                    var result_ = await _userManager.CreateAsync(identityUser, generatedPassword);
                    bool containsPasswordError_ = result_.Errors.Where(x => x.Code.StartsWith("Password")).Any();

                    if (containsPasswordError_ == false)// No Password errors found
                    {
                        containsPasswordError = false; // Set as false to break out of the loop
                        if (result_.Succeeded == true)
                        {
                            var data = new AssignUserToRole
                            {
                                Email = user.Email,
                                RoleName = "Security"
                            };

                            var assignresult = await _userManager.AddToRoleAsync(identityUser, data.RoleName);

                            if (assignresult.Succeeded)
                            {
                                _logger.LogInformation($"User {user.Email} role has been assigned successfully during registration");
                            }
                            var mailData = new MailData();
                            mailData.SenderEmail = user.Email;
                            mailData.SenderName = $"{user.FirstName} {user.LastName}";
                            mailData.EmailSubject = "OCC cleverchap_montessori USER CREDENTIALS";

                            string emailTemplate = @"Dear {2},

Kindly find below your login credentials for your OCC cleverchap_montessori platform access.

Username: {0}
Password: {1}

Best Regards,
Omega Community Church, cleverchap_montessori";


                            string message = string.Format(emailTemplate, user.Email, generatedPassword, user.FirstName);
                            mailData.EmailBody = message;

                            var mailResult = await _mailerService.SendSimpleMailAsync(mailData);

                            if (mailResult.Status == "01")
                            {
                                _logger.LogInformation($"User could not receive mail credentials");
                            }
                        }
                        finalResult = result_;
                        return finalResult;
                    }
                }

                if (result.Succeeded == true)
                {


                    var mailData = new MailData();
                    mailData.SenderEmail = user.Email;
                    mailData.SenderName = $"{user.FirstName} {user.LastName}";
                    mailData.EmailSubject = "OCC cleverchap_montessori USER CREDENTIALS";

                    string emailTemplate = @"Dear {2},

Kindly find below your login credentials for your OCC cleverchap_montessori platform access.

Username: {0}
Password: {1}

Best Regards,
Omega Community Church, cleverchap_montessori";


                    string message = string.Format(emailTemplate, user.Email, generatedPassword, user.FirstName);
                    mailData.EmailBody = message;

                    var mailResult = await _mailerService.SendSimpleMailAsync(mailData);

                    if (mailResult.Status == "01")
                    {
                        _logger.LogInformation($"User could not receive mail credentials");
                    }
                }
                finalResult = result;
                return finalResult;
            }
            catch (Exception ex)
            {
                return new IdentityResult();
            }

        }

        public async Task<bool> Login(LoginUser user)
        {
            var finalResult = false;
            var identityUser = await _userManager.FindByEmailAsync(user.UserName.ToUpper());
            if (identityUser is null)
            {
                return false;
            }

            if (!identityUser.EmailConfirmed) // If the user is not marked as enabled
            {
                _logger.LogInformation($"User has been disabled");
                finalResult = false;
               return finalResult;
            }

            if (!identityUser.LockoutEnabled) // If the user is marked as deleted
            {
                _logger.LogInformation($"User has been lockedout or marked as deleted");
                finalResult = false;
                return finalResult;
            }

            var result = await _userManager.CheckPasswordAsync(identityUser, user.Password);
            if (result != false)
            {
                finalResult = result;
            }

            return finalResult;
               
        }

        public TokenResponse GenerateAccessToken(LoginUser user)
        {
            try
            {
                var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Email,user.UserName),
                new Claim(ClaimTypes.Role,"Admin"),
            };

                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.GetSection("Jwt:Key").Value));

                var signingCred = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha512Signature);

                var securityToken = new JwtSecurityToken(
                    claims: claims,
                    expires: DateTime.Now.AddMinutes(60),
                    issuer: _config.GetSection("Jwt:Issuer").Value,
                    audience: _config.GetSection("Jwt:Audience").Value,
                    signingCredentials: signingCred);

                string tokenString = new JwtSecurityTokenHandler().WriteToken(securityToken);
                DateTime expirationTime = securityToken.ValidTo;
                return new TokenResponse
                {
                    AccessToken = tokenString,
                    ExpiresOn = expirationTime,
                    TokenType = "client-credentials",
                };
            }
            catch (Exception ex)
            {
                return new TokenResponse
                {
                    AccessToken = string.Empty,
                    ExpiresOn = DateTime.UtcNow,
                    TokenType = string.Empty,
                };
            }
        }

        public async Task<IdentityResult> ChangePassword(PasswordChange user)
        {
            var existinguser = await _userManager.FindByEmailAsync(user.Email);
            var finalResult = new IdentityResult();

            if (existinguser != null)
            {
                // Verify the current password
                var passwordIsValid = await _userManager.CheckPasswordAsync(existinguser, user.CurrentPassword);
                if (passwordIsValid)
                {
                    // Change Password
                    var changePasswordResult = await _userManager.ChangePasswordAsync(existinguser, user.CurrentPassword, user.NewPassword);

                    if (changePasswordResult.Succeeded)
                    {
                        finalResult = changePasswordResult;
                        _logger.LogInformation($"User password changed");
                      
                    }
                    else
                    {
                        _logger.LogInformation($"User password changes");
                    }
                    
                }
                else
                {
                    _logger.LogInformation($"User password incorrect");
                }
                return finalResult;
            }
            return finalResult;
            
        }


        public async Task<IdentityResult> ResetPassword(ResetPassword user)
        {
            try
            {
                var userName = user.Email.Split('@')[0];

                var generatedPassword = PasswordGenerator.GeneratePassword();

                var existinguser = await _userManager.FindByEmailAsync(user.Email);

                var finalResult = new IdentityResult();

                var token = await _userManager.GeneratePasswordResetTokenAsync(existinguser);

                var result = await _userManager.ResetPasswordAsync(existinguser, token, generatedPassword);

                bool containsPasswordError = result.Errors.Where(x => x.Code.StartsWith("Password")).Any();

                while (containsPasswordError == true)
                {
                    generatedPassword = PasswordGenerator.GeneratePassword();
                    var result_ = await _userManager.ResetPasswordAsync(existinguser, token, generatedPassword);
                    bool containsPasswordError_ = result_.Errors.Where(x => x.Code.StartsWith("Password")).Any();

                    if (containsPasswordError_ == false)// No Password errors found
                    {
                        containsPasswordError = false; // Set as false to break out of the loop
                        if (result_.Succeeded == true)
                        {
                            var mailData = new MailData();
                            mailData.SenderEmail = user.Email;
                            mailData.SenderName = $"{existinguser.FirstName} {existinguser.LastName}";
                            mailData.EmailSubject = "OCC cleverchap_montessori - NEW USER CREDENTIALS";

                            string emailTemplate = @"Dear {2},

Your password has been changed by your administrator.

Kindly find below your login credentials for your OCC cleverchap_montessori platform access.

Username: {0}
Password: {1}

Best Regards,
Omega Community Church, cleverchap_montessori";


                            string message = string.Format(emailTemplate, user.Email, generatedPassword, existinguser.FirstName);
                            mailData.EmailBody = message;

                            var mailResult = await _mailerService.SendSimpleMailAsync(mailData);

                            if (mailResult.Status == "01")
                            {
                                _logger.LogInformation($"User could not receive mail credentials");
                            }
                        }
                        finalResult = result_;
                        return finalResult;
                    }
                }

                if (result.Succeeded == true)
                {
                    var mailData = new MailData();
                    mailData.SenderEmail = user.Email;
                    mailData.SenderName = $"{existinguser.FirstName} {existinguser.LastName}";
                    mailData.EmailSubject = "OCC cleverchap_montessori - NEW USER CREDENTIALS";

                    string emailTemplate = @"Dear {2},

Your password has been changed by your administrator.

Kindly find below your login credentials for your OCC cleverchap_montessori platform access.

Username: {0}
Password: {1}

Best Regards,
Omega Community Church, cleverchap_montessori";


                    string message = string.Format(emailTemplate, user.Email, generatedPassword, existinguser.FirstName);
                    mailData.EmailBody = message;

                    var mailResult = await _mailerService.SendSimpleMailAsync(mailData);

                    if (mailResult.Status == "01")
                    {
                        _logger.LogInformation($"User could not receive mail credentials");
                    }
                }
                finalResult = result;
                return finalResult;
            }
            catch (Exception ex)
            {
                return new IdentityResult();
            }
        }

        public async Task<GeneralResponsePayload> GetAllRoles()
        {
            try
            {
                var existingroles = _roleManager.Roles.ToList();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "User roles retrieved successfully",
                    Data = new RecordsList
                    {
                        Total = existingroles.Count(),
                        Records = existingroles
                    }
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "01",
                    Message = "Could not retrieve user roles",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> CreateRole()
        {
            try
            {
                string[] roleNames = { "Admin", "Security", "Teacher", "Parent"};
                var createdRoles = new List<string>();

                foreach (var roleName in roleNames)
                {
                    var roleExists = await _roleManager.RoleExistsAsync(roleName);
                    if (roleExists)
                    {
                        return new GeneralResponsePayload
                        {
                            Status = "00",
                            Message = "Role already exist",
                            Data = new RecordsList
                            {
                                Total = null,
                                Records = null
                            }
                        };
                    }

                    if (!roleExists)
                    {
                        var roleResult_ = await _roleManager.CreateAsync(new IdentityRole(roleName));
                        if (roleResult_.Succeeded)
                        {
                            createdRoles.Add(roleName);
                            
                        }
                    }
                }

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Roles created successfully",
                    Data = new RecordsList
                    {
                        Total = createdRoles.Count,
                        Records = createdRoles
                    }
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "01",
                    Message = "Could not create roles",
                    Data = ex.Message
                };
            }
        }

        

        public async Task<GeneralResponsePayload> AllUsers()
        {
            try
            {
                var existingUsers = await _userManager.Users.ToListAsync();

                var usersWithoutPasswords = existingUsers.Select(user => new UserList
                {
                    Email = user.Email,
                    FirstName = user.FirstName,
                    FullName = user.FirstName + ' ' + user.LastName,
                    LastName = user.LastName,
                    PhoneNumber = user.PhoneNumber,
                    Role = _userManager.GetRolesAsync(user).Result?.FirstOrDefault()?.ToString(),
                    UserName = user.UserName,
                    ActiveStatus = user.EmailConfirmed,
                    DeletedStatus = user.LockoutEnabled
                    // Map other user properties here
                }).ToList();


                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Users retrieved successfully",
                    Data = new RecordsList
                    {
                        Total = usersWithoutPasswords.Count(),
                        Records = usersWithoutPasswords
                    }
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "01",
                    Message = "Could not retrieve users",
                    Data = ex.Message
                };
            }
        }

        //public async Task<GeneralResponsePayload> AddUsersToRole()
        //{
        //    try
        //    {
        //        var existingUsers = await _userManager.Users.ToListAsync();

        //        var usersWithoutPasswords = existingUsers.Select(user => new UserList
        //        {
        //            Email = user.Email,
        //            FirstName = user.FirstName,
        //            FullName = user.FirstName + user.LastName,
        //            LastName = user.LastName,
        //            PhoneNumber = user.PhoneNumber,
        //            Role = null,
        //            UserName = user.UserName
        //            // Map other user properties here
        //        }).ToList();


        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Users retrieved successfully",
        //            Data = new RecordsList
        //            {
        //                Total = usersWithoutPasswords.Count(),
        //                Records = usersWithoutPasswords
        //            }
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not retrieve users",
        //            Data = ex.Message
        //        };
        //    }
        //}



        public async Task<IdentityResult> AssignUserToRole(AssignUserToRole user)
        {
            try
            {
                var finalResult = new IdentityResult(); 
                var existingUser = await _userManager.FindByEmailAsync(user.Email.ToUpper());

                if (existingUser == null)
                {
                    _logger.LogInformation($"Could not find user");
                }

                var roleExist = await _roleManager.RoleExistsAsync(user.RoleName);

                if (roleExist == null)
                {
                    _logger.LogInformation($"Could not find role");
                }

                var result = await _userManager.AddToRoleAsync(existingUser, user.RoleName);

                if(result.Succeeded != true)
                {
                    return result;
                }

                finalResult = result;

                return finalResult;       
            }
            catch (Exception ex)
            {

                return new IdentityResult();
            }
        }

        public async Task<IdentityResult> RemoveUserFromRole(AssignUserToRole user)
        {
            try
            {
                var finalResult = new IdentityResult();
                var existingUser = await _userManager.FindByEmailAsync(user.Email.ToUpper());

                if (existingUser == null)
                {
                    _logger.LogInformation($"Could not find user");
                }

                var roleExist = await _roleManager.RoleExistsAsync(user.RoleName);

                if (roleExist == null)
                {
                    _logger.LogInformation($"Could not find role");
                }

                var result = await _userManager.RemoveFromRoleAsync(existingUser, user.RoleName);

                if (result.Succeeded != true)
                {
                    return result;
                }

                finalResult = result;

                return finalResult;
            }
            catch (Exception ex)
            {

                return new IdentityResult();
            }
        }

        public async Task<IdentityResult> ChangeUserRole(ChangeUserRole user)
        {
            try
            {
                var finalResult = new IdentityResult();
                var existingUser = await _userManager.FindByEmailAsync(user.Email.ToUpper());

                if (existingUser == null)
                {
                    _logger.LogInformation($"Could not find user");
                }

                var roleExist = await _roleManager.RoleExistsAsync(user.RoleName);

                if (roleExist == null)
                {
                    _logger.LogInformation($"Could not find role");
                }

                var result = await _userManager.RemoveFromRoleAsync(existingUser, user.ExsitingRole);

               
                if (result.Succeeded != false)
                {
                    var result_ = await _userManager.AddToRoleAsync(existingUser, user.RoleName);
                    if (result_.Succeeded != false)
                    {
                        return result_;
                    }     
                }

                finalResult = result;

                return finalResult;
            }
            catch (Exception ex)
            {

                return new IdentityResult();
            }
        }

        public async Task<GeneralResponsePayload> UserRoles(UserRole user)
        {

            try
            {
                var existingUser = await _userManager.FindByEmailAsync(user.Email.ToUpper());

                if (existingUser == null)
                {
                    _logger.LogInformation($"Could not find user");
                }

                var roles = await _userManager.GetRolesAsync(existingUser);

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "User roles retrieved successfully",
                    Data = new RecordsList
                    {
                        Total = roles.Count(),
                        Records = roles
                    }
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve user roles",
                    Data = ex.Message
                };
            }
        }

        public async Task<UserList> UserResource(LoginUser user)
        {
            try
            {
                var existingUser = await _userManager.FindByEmailAsync(user.UserName.ToUpper());

                IList<string> roles = await _userManager.GetRolesAsync(existingUser);

                string role = roles.FirstOrDefault();

                var seletedUser = new UserList
                {
                    Email = existingUser.Email,
                    FirstName = existingUser.FirstName,
                    FullName = existingUser.FirstName + " " + existingUser.LastName,
                    LastName = existingUser.LastName,
                    PhoneNumber = existingUser.PhoneNumber,
                    Role = role,
                    UserName = existingUser.UserName,
                    ActiveStatus = existingUser.EmailConfirmed,
                    DeletedStatus = existingUser.LockoutEnabled

                };
                return seletedUser;


            }
            catch (Exception ex)
            {
                return new UserList();
            }
        }
    }
}

