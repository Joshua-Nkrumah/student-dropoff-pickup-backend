﻿using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Context;
using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Parent;
using cleverchap_montessori.Entities;
using Microsoft.EntityFrameworkCore;

namespace cleverchap_montessori.Services
{
    public class ParentService : IParentService
    {
        private readonly IConfiguration _config;
        protected readonly CcmontessoriDbContext _db;
        protected readonly ILogger<ParentService> _logger;

        public ParentService(IConfiguration config, CcmontessoriDbContext db, ILogger<ParentService> logger)
        {
            _config = config;
            _logger = logger;
            _db = db;
        }

        public static string GenerateParentId()
        {
            // Generate a GUID
            Guid guid = Guid.NewGuid();
            // Get the first 5 digits of the GUID
            string shortGuid = guid.ToString().Substring(0, 7);
            // Combine with the prefix
            string prefixedGuid = "CCM" + shortGuid.ToUpper();
            return Guid.Parse(prefixedGuid).ToString();
        }

        //public async Task<GeneralResponsePayload> GetAllParentsAsync()
        //{
        //    try
        //    {
        //        var parents = await _db.Parents.OrderByDescending(m => m.CreatedAt).ToListAsync();

        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Parents retrieved successfully",
        //            Data = new RecordsList
        //            {
        //                Total = parents.Count(),
        //                Records = parents
        //            }
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "02",
        //            Message = "Could not retrieve students",
        //            Data = ex.Message
        //        };
        //    }
        //}

        
          public  async Task<GeneralResponsePayload> GetAllParentsAsync()
            {
            try
            {
                var contributions = await _db.Parents.OrderByDescending(m => m.CreatedAt).ToListAsync();
                var details = (from parent in contributions
                               join student in _db.Students
                              on parent.StudentId equals student.StudentId.ToString()
                               select new
                                       {
                                  parent,
                                  student
                              }).ToList();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Parents retrieved successfully",
                    Data = new RecordsList
                    {
                        Total = details.Count(),
                        Records = details
                    }
                };

            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve parents",
                    Data = ex.Message
                };
            }
        }


        public async Task<GeneralResponsePayload> CreateParentAsync(AddParent Parent)
        {
            try
            {
                _logger.LogInformation($"Adding only parent: {Parent.FirstName} {Parent.LastName}");
                var now = DateTime.UtcNow;
                var parentId = Guid.NewGuid();

                var member_ = new Parent()
                {
                    FirstName = Parent.FirstName,
                    LastName = Parent.LastName,
                    StudentId = Parent.StudentId,
                    CreatedAt = now,
                    CreatedBy = Parent.CreatedBy,
                    ParentId = parentId,
                    UpdatedAt = now,
                    Email = Parent.EmailAddress ?? "",
                    Phone = Parent.PhoneNumber,
                    Address = Parent.Location,
                    Status = "Active",
                    Nationality = Parent.Nationality,
                    Type = Parent.Type

                };
                _db.Add(member_);
                await _db.SaveChangesAsync();
                _logger.LogInformation($"New Parent Added: {Parent.FirstName} {Parent.LastName}");
                var result = new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Parent added successfully",
                    Data = member_
                };

                return result;

            }
            catch (Exception ex)
            {
                var result = new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not add new parent",
                    Data = ex.Message
                };

                return result;
            }
        }


        public async Task<GeneralResponsePayload> GetParentByIdAsync(SingleParent Parent)
        {
            try
            {
                var existingParent = await _db.Parents.FindAsync(Parent.ParentId);

                if (existingParent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Parent not found",
                        Data = null
                    };
                }

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Parent retrieved successfully",
                    Data = existingParent
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve parent",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> UpdateParentAsync(UpdateParent Parent)
        {
            _logger.LogInformation($"Adding only parent: {Parent.FirstName} {Parent.LastName}");
            var now = DateTime.UtcNow;
            try
            {
                //var existingParent = await _db.Parents.FirstOrDefaultAsync(parent => parent.ParentId == Parent.ParentId);
                var existingParent = await _db.Parents.FindAsync(Parent.ParentId);

                if (existingParent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Parent not found",
                        Data = null
                    };
                }

                _logger.LogInformation($"Updating parent: {existingParent.FirstName} {existingParent.LastName}");


                existingParent.FirstName = Parent.FirstName;
                existingParent.LastName = Parent.LastName;
                existingParent.CreatedAt = now;
                existingParent.CreatedBy = Parent.CreatedBy;
                existingParent.UpdatedAt = now;
                existingParent.Email = Parent.EmailAddress ?? "";
                existingParent.Phone = Parent.PhoneNumber;
                existingParent.Address = Parent.Location;
                existingParent.Status = "Active";
                existingParent.Nationality = Parent.Nationality;
                existingParent.Type = Parent.Type;

                await _db.SaveChangesAsync();
                _logger.LogInformation($"Parent updated: {existingParent.FirstName} {existingParent.LastName}");
                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Parent updated successfully",
                    Data = existingParent
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not update parent",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> DeleteParentAsync(SingleParent Parent)
        {
            try
            {
                var existingParent = await _db.Parents.FindAsync(Parent.ParentId);

                if (existingParent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Parent not found",
                        Data = null
                    };
                }

                _db.Parents.Remove(existingParent);
                await _db.SaveChangesAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Parent deleted successfully",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not delete parent",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> SoftDeleteParentAsync(SingleParent Parent)
        {
            try
            {
                var existingParent = await _db.Parents.FindAsync(Parent.ParentId);
                var now = DateTime.UtcNow;
                //var existingParent = await _db.Parents.FirstOrDefaultAsync(parent => parent.ParentId == Guid.Parse(Parent!.ParentId));
                if (existingParent == null)
                {
                    return new GeneralResponsePayload
                    {
                        Status = "01",
                        Message = "Parent not found",
                        Data = null
                    };
                }

                existingParent.Status = "Deleted"; // Mark as deleted or Move to Trash
                existingParent.UpdatedAt = now;
                await _db.SaveChangesAsync();

                return new GeneralResponsePayload
                {
                    Status = "00",
                    Message = "Parent marked as deleted",
                    Data = null
                };
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not soft-delete parent",
                    Data = ex.Message
                };
            }
        }

        public async Task<GeneralResponsePayload> GetParentYearSummaryAsync(RecordsByMonthDto yearFilter)
        {
            try
            {
                var query = await _db.Parents
               .Where(m => m.CreatedAt!.Value!.Year == yearFilter.Year)
               .GroupBy(m => new { m.CreatedAt!.Value!.Year, m.CreatedAt!.Value!.Month })
               .Select(group => new RecordsByMonthDto
               {
                   Year = group.Key.Year,
                   Month = group.Key.Month,
                   TotalRecords = group.Count()
               }).ToListAsync();

                var result = new GeneralResponsePayload
                {
                    Status = "00",
                    Message = $"Parent summary for {yearFilter!.Year}",
                    Data = new RecordsList
                    {
                        Total = query.Count(),
                        Records = query
                    }
                };

                return result;
            }
            catch (Exception ex)
            {

                var result = new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve parent yearly summary",
                    Data = ex.Message
                };

                return result;

            }
        }

    }
}

