﻿using System;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using System.Text;
using cleverchap_montessori.Models.Auth;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using cleverchap_montessori.Services.Interfaces;
using cleverchap_montessori.Context;
using cleverchap_montessori.Models;
using Microsoft.EntityFrameworkCore;
using cleverchap_montessori.Payloads.Request;
//using cleverchap_montessori.Migrations;
using cleverchap_montessori.Payloads.Request.Teacher;

namespace cleverchap_montessori.Services
{
    public class TeacherService : ITeacherService
    {
        private readonly IConfiguration _config;
        //protected readonly CcmontessoriDbContext _db;
        protected readonly ILogger<TeacherService> _logger;

        //public TeacherService(IConfiguration config, CcmontessoriDbContext db, ILogger<TeacherService> logger)
        //{
        //    _config = config;
        //    _logger = logger;
        //    _db = db;
        //}



        Task<GeneralResponsePayload> ITeacherService.GetAllTeachersAsync()
        {
            throw new NotImplementedException();
        }

        Task<GeneralResponsePayload> ITeacherService.CreateTeacherAsync(AddTeacher Teacher)
        {
            throw new NotImplementedException();
        }

        Task<GeneralResponsePayload> ITeacherService.GetTeacherByIdAsync(SingleTeacher id)
        {
            throw new NotImplementedException();
        }

        Task<GeneralResponsePayload> ITeacherService.UpdateTeacherAsync(UpdateTeacher Teacher)
        {
            throw new NotImplementedException();
        }

        Task<GeneralResponsePayload> ITeacherService.DeleteTeacherAsync(SingleTeacher id)
        {
            throw new NotImplementedException();
        }

        Task<GeneralResponsePayload> ITeacherService.SoftDeleteTeacherAsync(SingleTeacher id)
        {
            throw new NotImplementedException();
        }

        Task<GeneralResponsePayload> ITeacherService.GetTeacherYearSummaryAsync(RecordsByMonthDto Teacher)
        {
            throw new NotImplementedException();
        }


        //public async Task<GeneralResponsePayload> CreateMemberAsync(AddMember member)
        //{
        //    try
        //    {
        //        _logger.LogInformation($"Adding only member: {member.FirstName} {member.LastName}");
        //        var now = DateTime.UtcNow;

        //        //var memberExists = _db.Members.Any(item => item.EmailAddress == member.EmailAddress); // Modify the condition as needed

        //        //if (memberExists)
        //        //{
        //        //    var result_ = new GeneralResponsePayload
        //        //    {
        //        //        Status = "01",
        //        //        Message = "Could not add member, member already exists",
        //        //        Data = null
        //        //    };

        //        //    return result_;
        //        //}
        //        //else
        //        //{
        //        var member_ = new Member()
        //        {
        //            FirstName = member.FirstName,
        //            LastName = member.LastName,
        //            EmergencyContact = member.EmergencyContact ?? "",
        //            Age = member.Age,
        //            AdditionalInformation = member.AdditionalInformation,
        //            Children = member.Children,
        //            CreatedAt = now,
        //            CreatedBy = member.CreatedBy,
        //            DateOfBirth = member.DateOfBirth,
        //            DateJoined = member.DateJoined,
        //            Gender = member.Gender,
        //            MaritalStatus = member.MaritalStatus,
        //            MemberId = Guid.NewGuid(),
        //            MembershipStatus = member.MembershipStatus,
        //            MembershipType = member.MembershipType,
        //            MiddleName = member.MiddleName,
        //            Occupation = member.Occupation,
        //            Photograph = member.Photograph,
        //            UpdatedAt = now,
        //            EmailAddress = member.EmailAddress ?? "",
        //            PhoneNumber = member.PhoneNumber,
        //            Location = member.Location
        //        };
        //        _db.Add(member_);
        //        await _db.SaveChangesAsync();
        //        _logger.LogInformation($"New Member Added: {member.FirstName} {member.LastName}");
        //        var result = new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Member added successfully",
        //            Data = member_
        //        };

        //        return result;
        //        //}


        //    }
        //    catch (Exception ex)
        //    {
        //        var result = new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not add new member",
        //            Data = ex.Message
        //        };

        //        return result;
        //    }
        //}

        //public async Task<GeneralResponsePayload> GetMemberByIdAsync(object memberId)
        //{
        //    try
        //    {
        //        //var existingMember = await _db.Members.FindAsync(id);
        //        var existingMember = await _db.Members.FirstOrDefaultAsync(member => member.MemberId == (Guid)memberId);

        //        if (existingMember == null)
        //        {
        //            return new GeneralResponsePayload
        //            {
        //                Status = "01",
        //                Message = "Member not found",
        //                Data = null
        //            };
        //        }

        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Member retrieved successfully",
        //            Data = existingMember
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not retrieve member",
        //            Data = ex.Message
        //        };
        //    }
        //}

        //public async Task<GeneralResponsePayload> GetAllMembersAsync()
        //{
        //    try
        //    {
        //        var members = await _db.Members.OrderByDescending(m => m.CreatedAt).ToListAsync();

        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Members retrieved successfully",
        //            Data = new RecordsList
        //            {
        //                Total = members.Count(),
        //                Records = members
        //            }
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not retrieve members",
        //            Data = ex.Message
        //        };
        //    }
        //}

        //public async Task<GeneralResponsePayload> UpdateMemberAsync(UpdateMember member)
        //{
        //    _logger.LogInformation($"Adding only member: {member.FirstName} {member.LastName}");
        //    var now = DateTime.UtcNow;
        //    try
        //    {

        //        var existingMember = await _db.Members.FirstOrDefaultAsync(member => member.MemberId == member.MemberId);

        //        if (existingMember == null)
        //        {
        //            return new GeneralResponsePayload
        //            {
        //                Status = "01",
        //                Message = "Member not found",
        //                Data = null
        //            };
        //        }

        //        _logger.LogInformation($"Updating member: {existingMember.FirstName} {existingMember.LastName}");

        //        existingMember.FirstName = member.FirstName;
        //        existingMember.LastName = member.LastName;
        //        existingMember.EmergencyContact = member.EmergencyContact;
        //        existingMember.EmergencyContact = member.EmergencyContact ?? "";
        //        existingMember.Age = member.Age;
        //        existingMember.AdditionalInformation = member.AdditionalInformation;
        //        existingMember.Children = member.Children;
        //        //existingMember.CreatedAt = now;
        //        //existingMember.CreatedBy = member.CreatedBy;
        //        existingMember.DateOfBirth = member.DateOfBirth;
        //        //existingMember.DateJoined = member.DateJoined;
        //        existingMember.Gender = member.Gender;
        //        existingMember.MaritalStatus = member.MaritalStatus;
        //        existingMember.MembershipStatus = member.MembershipStatus;
        //        existingMember.MembershipType = member.MembershipType;
        //        existingMember.MiddleName = member.MiddleName;
        //        existingMember.Occupation = member.Occupation;
        //        existingMember.Photograph = member.Photograph;
        //        existingMember.EmailAddress = member.EmailAddress;
        //        existingMember.PhoneNumber = member.PhoneNumber;
        //        existingMember.Location = member.Location;
        //        existingMember.UpdatedAt = now;
        //        await _db.SaveChangesAsync();
        //        _logger.LogInformation($"Member updated: {existingMember.FirstName} {existingMember.LastName}");
        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Member updated successfully",
        //            Data = existingMember
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not update member",
        //            Data = ex.Message
        //        };
        //    }
        //}

        //public async Task<GeneralResponsePayload> DeleteMemberAsync(object memberId)
        //{
        //    try
        //    {
        //        var existingMember = await _db.Members.FindAsync(memberId);

        //        if (existingMember == null)
        //        {
        //            return new GeneralResponsePayload
        //            {
        //                Status = "01",
        //                Message = "Member not found",
        //                Data = null
        //            };
        //        }

        //        _db.Members.Remove(existingMember);
        //        await _db.SaveChangesAsync();

        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Member deleted successfully",
        //            Data = null
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not delete member",
        //            Data = ex.Message
        //        };
        //    }
        //}

        //public async Task<GeneralResponsePayload> SoftDeleteMemberAsync(SingleMember memberId)
        //{
        //    try
        //    {
        //        //var existingMember = await _db.Members.FindAsync(id);
        //        var memberId_ = memberId.MemberID;
        //        var existingMember = await _db.Members.FirstOrDefaultAsync(member => member.MemberId == Guid.Parse(memberId!.MemberID));
        //        if (existingMember == null)
        //        {
        //            return new GeneralResponsePayload
        //            {
        //                Status = "01",
        //                Message = "Member not found",
        //                Data = null
        //            };
        //        }

        //        existingMember.IsDeleted = "deleted"; // Assuming you have a property like IsDeleted
        //        existingMember.DeletedAt = DateTime.UtcNow;
        //        await _db.SaveChangesAsync();

        //        return new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = "Member marked as deleted",
        //            Data = null
        //        };
        //    }
        //    catch (Exception ex)
        //    {
        //        return new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not soft-delete member",
        //            Data = ex.Message
        //        };
        //    }
        //}

        //public async Task<GeneralResponsePayload> GetMemberYearSummaryAsync(RecordsByMonthDto yearFilter)
        //{
        //    try
        //    {
        //        var query = await _db.Members
        //       .Where(m => m.CreatedAt!.Value!.Year == yearFilter.Year)
        //       .GroupBy(m => new { m.CreatedAt!.Value!.Year, m.CreatedAt!.Value!.Month })
        //       .Select(group => new RecordsByMonthDto
        //       {
        //           Year = group.Key.Year,
        //           Month = group.Key.Month,
        //           TotalRecords = group.Count()
        //       }).ToListAsync();

        //        var result = new GeneralResponsePayload
        //        {
        //            Status = "00",
        //            Message = $"Member summary for {yearFilter!.Year}",
        //            Data = new RecordsList
        //            {
        //                Total = query.Count(),
        //                Records = query
        //            }
        //        };

        //        return result;
        //    }
        //    catch (Exception ex)
        //    {

        //        var result = new GeneralResponsePayload
        //        {
        //            Status = "01",
        //            Message = "Could not retrieve member yearly summary",
        //            Data = ex.Message
        //        };

        //        return result;

        //    }
        //}


    }
}

