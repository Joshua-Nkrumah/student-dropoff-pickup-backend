﻿using System;
using System.Text.Json.Serialization;

namespace cleverchap_montessori.Models
{
	public class GeneralResponsePayload
	{
        [JsonPropertyName("status")]
        public string? Status { get; set; }

        [JsonPropertyName("message")]
        public string? Message { get; set; }

        [JsonPropertyName("data")]
        public object? Data { get; set; }
    }
}
