﻿using System;
namespace cleverchap_montessori.Models
{
	public class RecordsByYearMonthDto
	{
        public int Year { get; set; }
        public int Month { get; set; }
        public int TotalRecords { get; set; }
    }
}

