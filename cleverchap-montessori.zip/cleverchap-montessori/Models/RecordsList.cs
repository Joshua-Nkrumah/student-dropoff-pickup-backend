﻿using System;
using System.Text.Json.Serialization;

namespace cleverchap_montessori.Models
{
	public class RecordsList
    {
        [JsonPropertyName("total")]
        public int? Total { get; set; }

        [JsonPropertyName("records")]
        public IEnumerable<object>? Records { get; set; }
    }
}

