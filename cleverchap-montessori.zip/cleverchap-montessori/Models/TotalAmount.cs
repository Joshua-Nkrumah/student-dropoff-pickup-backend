﻿using System;
using System.Text.Json.Serialization;

namespace cleverchap_montessori.Models
{
	public class TotalAmount
	{
        [JsonPropertyName("total")]
        public decimal? Total { get; set; }

        [JsonPropertyName("records")]
        public IEnumerable<object>? Records { get; set; }
    }
}

