﻿using System;
using System.Text.Json.Serialization;

namespace cleverchap_montessori.Models.Auth
{ 
    public class AuthResponse
    {
        [JsonPropertyName("status")]
        public string? Status { get; set; }

        [JsonPropertyName("message")]
        public string? Message { get; set; }

        [JsonPropertyName("data")]
        public object? Data { get; set; }

        //[JsonPropertyName("data")]
        //public AuthData? Data { get; set; }
    }

    public  class AuthData
    {
        [JsonPropertyName("succeeded")]
        public bool Succeeded { get; set; }

        [JsonPropertyName("errors")]
        public object? Errors { get; set; }

        //[JsonPropertyName("errors")]
        //public List<AuthError>? Errors { get; set; }
    }

    public class LoginData
    {
        [JsonPropertyName("username")]
        public string? Username { get; set; }

        [JsonPropertyName("accessToken")]
        public string? AccessToken { get; set; }

        [JsonPropertyName("expiration")]
        public DateTime? Expiration { get; set; }

        [JsonPropertyName("refreshToken")]
        public string? RefreshToken { get; set; }

        [JsonPropertyName("userResource")]
        public object? UserResource { get; set; }
    }

    public  class AuthError
    {
        [JsonPropertyName("code")]
        public string? Code { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }
    }
}

