﻿using System;
namespace cleverchap_montessori.Models.Auth
{
    public class UserDto
    {
        public required string Username { get; set; }
        public required string Password { get; set; }
    }
}

