﻿using System;
using Microsoft.AspNetCore.Identity;

namespace cleverchap_montessori.Models.Auth
{
    public class ApplicationUser : IdentityUser
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Photograph { get; set; }
    }
}

