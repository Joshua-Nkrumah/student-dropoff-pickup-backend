﻿using System;
namespace cleverchap_montessori.Models.Auth
{
	public class ChangeUserRole
	{
        public string Email { get; set; }
        public string RoleName { get; set; }
        public string ExsitingRole { get; set; }
    }
}


