﻿using System;
namespace cleverchap_montessori.Models.Auth
{
	public class UserRole
	{
		public string Email { get; set; }
	}
}

