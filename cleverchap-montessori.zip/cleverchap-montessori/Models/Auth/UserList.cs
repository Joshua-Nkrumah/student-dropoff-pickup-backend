﻿using System;
namespace cleverchap_montessori.Models.Auth
{
	public class UserList
	{
        public string? UserName { get; set; }
        public string? Email { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? FullName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Role { get; set; }
        public bool? ActiveStatus { get; set; }
        public bool? DeletedStatus { get; set; }

    }
}

