﻿using System;
namespace cleverchap_montessori.Models.Auth
{
	public class PasswordChange
	{
        public string Email { get; set; }
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmPassword { get; set; }
    }
}

