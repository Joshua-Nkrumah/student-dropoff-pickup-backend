﻿using System;
namespace cleverchap_montessori.Models.Auth
{
	public class AssignUserToRole
	{
		public string Email { get; set; }
		public string RoleName { get; set; }
    }
}

