﻿using System;
namespace cleverchap_montessori.Models.Auth
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Group { get; set; }
    }
}

