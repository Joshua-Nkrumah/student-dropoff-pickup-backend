﻿using System;
using System.Text.Json.Serialization;

namespace cleverchap_montessori.Models.Auth
{
    public class TokenResponse
    {
        [JsonPropertyName("token_type")]
        public string? TokenType { get; set; }

        [JsonPropertyName("expires_on")]
        public DateTime ExpiresOn { get; set; }

        [JsonPropertyName("access_token")]
        public string? AccessToken { get; set; }
    }
}

