﻿using System;
namespace cleverchap_montessori.Models.Auth
{
    public class LoginUser
    {
        public string UserName { get; set; } //Should be the Email
        public string Password { get; set; }
    }
}

