﻿using System;
namespace cleverchap_montessori.Models
{
	public class RecordsByMonthDto
    {
        public int? Year { get; set; }
        public int? Month { get; set; }
        public int? TotalRecords { get; set; }
    }
}

