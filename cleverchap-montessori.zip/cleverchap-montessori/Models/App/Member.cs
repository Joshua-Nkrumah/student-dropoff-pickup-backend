﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace cleverchap_montessori.Models.App
{
	public class Member
	{
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid MemberId { get; set; }
        public string? FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string? LastName { get; set; }
        public string? Photograph { get; set; }
        public string? Age { get; set; }
        public string? DateOfBirth { get; set; }
        public string? Gender { get; set; }
        public string? EmailAddress { get; set; }
        public string? Location { get; set; }
        public string? PhoneNumber { get; set; }
        public string? EmergencyContact { get; set; }
        public string? DateJoined { get; set; }
        public string? MaritalStatus { get; set; }
        public string? MembershipStatus { get; set; }
        public string? Children { get; set; }
        public string? Occupation { get; set; }
        public string? MembershipType { get; set; }
        public string? AdditionalInformation { get; set; }
        public string? CreatedBy { get; set; }
        public string? IsDeleted { get; set; }
        public DateTime? DeletedAt { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}

