﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace cleverchap_montessori.Models.App
{
	public class Contribution
	{
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid ContributionId { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public decimal Amount { get; set; }
        public string? Description { get; set; }
        public string? ContributionStatus { get; set; }
        public string? CreatedBy { get; set; }
        public string? Remarks { get; set; }
        public string? IsDeleted { get; set; }
        public string? MemberId { get; set; }
        public DateTime? DeletedAt { get; set; }
        public DateTime ContributionDate { get; set; }
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}

