﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace cleverchap_montessori.Models.App
{
	public class WelfareGroup
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int WelfareId { get; set; } 
        public string Name { get; set; }
        public string Group { get; set; }
    }
}

