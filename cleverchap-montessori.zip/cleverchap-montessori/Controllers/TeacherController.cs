﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Payloads.Request.Teacher;
using cleverchap_montessori.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cleverchap_montessori.Controllers
{
    [Route("api/")]
    public class TeacherController : ControllerBase
    {
        private readonly ITeacherService _teacherService;

        public TeacherController(ITeacherService teacherService)
        {
            _teacherService = teacherService;
        }

        [HttpPost("teacher/create-teacher")]
        public async Task<GeneralResponsePayload> CreateTeacher([FromBody] AddTeacher payload)
        {
            var result = await _teacherService.CreateTeacherAsync(payload);
            return result;
        }

        [HttpPost("teacher/get-teacher")]
        public async Task<GeneralResponsePayload> GetTeacherByIdAsync([FromBody] SingleTeacher id)
        {
            var result = await _teacherService.GetTeacherByIdAsync(id);
            return result;
        }

        [HttpPost("teacher/get-all-teachers")]
        public async Task<GeneralResponsePayload> GetAllTeachersAsync()
        {
            var result = await _teacherService.GetAllTeachersAsync();
            return result;
        }


        [HttpPost("teacher/update-teacher")]
        public async Task<GeneralResponsePayload> UpdateTeacherAsync([FromBody] UpdateTeacher updatedTeacher)
        {
            var result = await _teacherService.UpdateTeacherAsync(updatedTeacher);
            return result;
        }

        [HttpPost("teacher/delete-teacher")]
        public async Task<GeneralResponsePayload> DeleteTeacherAsync([FromBody] SingleTeacher id)
        {
            var result = await _teacherService.DeleteTeacherAsync(id);
            return result;
        }

        [HttpPost("teacher/soft-delete-teacher")]
        public async Task<GeneralResponsePayload> SoftDeleteTeacherAsync([FromBody] SingleTeacher id)
        {
            var result = await _teacherService.SoftDeleteTeacherAsync(id);
            return result;
        }

        [HttpPost("teacher/year-summary")]
        public async Task<GeneralResponsePayload> GetTeacherYearSummaryAsync([FromBody] RecordsByMonthDto id)
        {
            var result = await _teacherService.GetTeacherYearSummaryAsync(id);
            return result;
        }
    }
}

