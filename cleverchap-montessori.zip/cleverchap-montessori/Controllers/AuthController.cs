﻿using System;
using Microsoft.AspNetCore.Mvc;
using cleverchap_montessori.Models;
using cleverchap_montessori.Models.Auth;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Services;
using cleverchap_montessori.Services.Interfaces;

namespace cleverchap_montessori.Controllers
{
    [Route("api/")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("auth/register")]
        public async Task<AuthResponse> RegisterUser([FromBody] RegisterUser user)
        {
            try
            {
                var registrationResult = await _authService.RegisterUser(user);

                if (registrationResult.Succeeded == true)
                {

                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "Registration Successful",
                        Data = new AuthData
                        {
                            Succeeded = registrationResult.Succeeded,
                            Errors = registrationResult.Errors
                        }
                    };
                    return successfulResult;

                }
                else
                {
                    var failedResult = new AuthResponse
                    {

                        Status = "01",
                        Message = "Registration Failed",
                        Data = new AuthData
                        {
                            Succeeded = registrationResult.Succeeded,
                            Errors = registrationResult.Errors
                        }
                    };

                    return failedResult;
                }
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {

                    Status = "02",
                    Message = "Registration Failed",
                    Data = ex.Message
                };

                return failedResult;

            }       
        }

        [HttpPost("auth/register-without-password")]
        public async Task<AuthResponse> RegisterUserWithGeneratedPassword([FromBody] RegisterUserOnly user)
        {
            try
            {
                var registrationResult = await _authService.RegisterUserWithGeneratedPassword(user);

                if (registrationResult.Succeeded == true)
                {

                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "Registration Successful",
                        Data = new AuthData
                        {
                            Succeeded = registrationResult.Succeeded,
                            Errors = registrationResult.Errors
                        }
                    };
                    return successfulResult;

                }
                else
                {
                    var failedResult = new AuthResponse
                    {

                        Status = "01",
                        Message = "Registration Failed",
                        Data = new AuthData
                        {
                            Succeeded = registrationResult.Succeeded,
                            Errors = registrationResult.Errors
                        }
                    };

                    return failedResult;
                }
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {

                    Status = "02",
                    Message = "Registration Failed",
                    Data = ex.Message
                };
                return failedResult;
            }
        }
        

        [HttpPost("auth/change-password")]
        public async Task<AuthResponse> ChangePassword([FromBody] PasswordChange user)
        {
            try
            {
                var passwordChangeResult = await _authService.ChangePassword(user);

                if (passwordChangeResult.Succeeded == true)
                {

                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "Password Change Successful",
                        Data = new AuthData
                        {
                            Succeeded = passwordChangeResult.Succeeded,
                            Errors = passwordChangeResult.Errors
                        }
                    };
                    return successfulResult;

                }
                else
                {
                    var failedResult = new AuthResponse
                    {

                        Status = "01",
                        Message = "Password Change Failed",
                        Data = new AuthData
                        {
                            Succeeded = passwordChangeResult.Succeeded,
                            Errors = passwordChangeResult.Errors
                        }
                    };

                    return failedResult;
                }
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {

                    Status = "02",
                    Message = "Password Change Failed",
                    Data = ex.Message
                };

                return failedResult;
            }
        }


        [HttpPost("auth/reset-password")]
        public async Task<AuthResponse> ResetPassword([FromBody] ResetPassword user)
        {
            try
            {
                var passwordChangeResult = await _authService.ResetPassword(user);

                if (passwordChangeResult.Succeeded == true)
                {

                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "Reset Password Successful",
                        Data = new AuthData
                        {
                            Succeeded = passwordChangeResult.Succeeded,
                            Errors = passwordChangeResult.Errors
                        }
                    };
                    return successfulResult;

                }
                else
                {
                    var failedResult = new AuthResponse
                    {

                        Status = "01",
                        Message = "Reset Password Failed",
                        Data = new AuthData
                        {
                            Succeeded = passwordChangeResult.Succeeded,
                            Errors = passwordChangeResult.Errors
                        }
                    };

                    return failedResult;
                }
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {

                    Status = "02",
                    Message = "Reset Password Failed",
                    Data = ex.Message
                };

                return failedResult;
            }
        }


        [HttpPost("auth/login")]
        public async Task<AuthResponse> Login([FromBody] LoginUser user)
        {
            try
            {

                if (!ModelState.IsValid)
                {
                    var invalidRequestPayload = new AuthResponse
                    {
                        Status = "01",
                        Message = "Invalid Request Payload",
                        Data = null
                    };

                    return invalidRequestPayload;
                }

                var LoginResult = await _authService.Login(user);

                if (LoginResult)
                {
                    var tokenString = _authService.GenerateAccessToken(user);
                    var userResource = await _authService.UserResource(user);
                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "Login Successful",
                        Data = new LoginData
                        {
                            AccessToken = tokenString.AccessToken,
                            Expiration = tokenString.ExpiresOn,
                            RefreshToken = null,
                            Username = user.UserName,
                            UserResource = userResource
                        }
                    };

                    return successfulResult;
                }
                var failedResult = new AuthResponse
                {
                    Status = "01",
                    Message = "Login Failed",
                    Data = LoginResult
                };

                return failedResult;
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {
                    Status = "02",
                    Message = "Login Failed",
                    Data = ex.Message
                };

                return failedResult;
            }
        }


        [HttpPost("auth/get-roles")]
        public async Task<GeneralResponsePayload> GetAllRoles()
        {
            try
            {
                var result = await _authService.GetAllRoles();
                return result;
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve user roles",
                    Data = ex.Message
                };
            }
        }

        [HttpPost("auth/create-roles")]
        public async Task<GeneralResponsePayload> CreateRole()
        {
            try
            {
                var result = await _authService.CreateRole();
                return result;
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not create user roles",
                    Data = ex.Message
                };
            }
         
        }

        [HttpPost("auth/all-users")]
        public async Task<GeneralResponsePayload> AllUsers()
        {
            try
            {
                var result = await _authService.AllUsers();
                return result;
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve all users",
                    Data = ex.Message
                };

            }
        }

        [HttpPost("auth/user-roles")]
        public async Task<GeneralResponsePayload> UserRoles([FromBody] UserRole user)
        {
            try
            {
                var result = await _authService.UserRoles(user);
                return result;
            }
            catch (Exception ex)
            {
                return new GeneralResponsePayload
                {
                    Status = "02",
                    Message = "Could not retrieve user roles",
                    Data = ex.Message
                };
            }
           
        }


        [HttpPost("auth/assign-user-to-role")]
        public async Task<AuthResponse> AssignUserToRole([FromBody] AssignUserToRole user)
        {
            try
            {
                var result = await _authService.AssignUserToRole(user);
                if (result.Succeeded == true)
                {

                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "User to Role Pairing Successful",
                        Data = new AuthData
                        {
                            Succeeded = result.Succeeded,
                            Errors = result.Errors
                        }
                    };
                    return successfulResult;

                }
                else
                {
                    var failedResult = new AuthResponse
                    {

                        Status = "01",
                        Message = "User to Role Pairing Failed",
                        Data = new AuthData
                        {
                            Succeeded = result.Succeeded,
                            Errors = result.Errors
                        }
                    };

                    return failedResult;
                }
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {

                    Status = "02",
                    Message = "User to Role Pairing Failed",
                    Data = ex.Message
                };

                return failedResult;
            }
        }


        [HttpPost("auth/remove-user-from-role")]
        public async Task<AuthResponse> RemoveUserFromRole([FromBody] AssignUserToRole user)
        {
            try
            {
                var result = await _authService.RemoveUserFromRole(user);
                if (result.Succeeded == true)
                {

                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "User to role removal successful",
                        Data = new AuthData
                        {
                            Succeeded = result.Succeeded,
                            Errors = result.Errors
                        }
                    };
                    return successfulResult;

                }
                else
                {
                    var failedResult = new AuthResponse
                    {

                        Status = "01",
                        Message = "User to role removal failed",
                        Data = new AuthData
                        {
                            Succeeded = result.Succeeded,
                            Errors = result.Errors
                        }
                    };

                    return failedResult;
                }
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {

                    Status = "02",
                    Message = "Could not remove user from role",
                    Data = ex.Message
                };

                return failedResult;

            }
        }

        [HttpPost("auth/change-user-role")]
        public async Task<AuthResponse> ChangeUserRole([FromBody] ChangeUserRole user)
        {
            try
            {
                var result = await _authService.ChangeUserRole(user);
                if (result.Succeeded == true)
                {

                    var successfulResult = new AuthResponse
                    {
                        Status = "00",
                        Message = "User's role changed successfully",
                        Data = new AuthData
                        {
                            Succeeded = result.Succeeded,
                            Errors = result.Errors
                        }
                    };
                    return successfulResult;

                }
                else
                {
                    var failedResult = new AuthResponse
                    {

                        Status = "01",
                        Message = "Could not change user's role",
                        Data = new AuthData
                        {
                            Succeeded = result.Succeeded,
                            Errors = result.Errors
                        }
                    };

                    return failedResult;
                }
            }
            catch (Exception ex)
            {
                var failedResult = new AuthResponse
                {

                    Status = "02",
                    Message = "Could not change user's role",
                    Data = ex.Message
                };

                return failedResult;
            }
        }


        
    }
}

