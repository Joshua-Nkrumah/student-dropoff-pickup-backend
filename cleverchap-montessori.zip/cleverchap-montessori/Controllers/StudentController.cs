﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Student;
using cleverchap_montessori.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cleverchap_montessori.Controllers
{

    [Route("api/")]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpPost("student/create-student")]
        public async Task<GeneralResponsePayload> CreateStudent([FromBody] AddStudent payload)
        {
            var result = await _studentService.CreateStudentAsync(payload);
            return result;
        }

        [HttpPost("student/get-student")]
        public async Task<GeneralResponsePayload> GetStudentByIdAsync([FromBody] SingleStudent id)
        {
            var result = await _studentService.GetStudentByIdAsync(id);
            return result;
        }

        [HttpPost("student/get-all-students")]
        public async Task<GeneralResponsePayload> GetAllStudentsAsync()
        {
            var result = await _studentService.GetAllStudentsAsync();
            return result;
        }


        [HttpPost("student/update-student")]
        public async Task<GeneralResponsePayload> UpdateStudentAsync([FromBody] UpdateStudent updatedStudent)
        {
            var result = await _studentService.UpdateStudentAsync(updatedStudent);
            return result;
        }


        [HttpPost("student/delete-student")]
        public async Task<GeneralResponsePayload> DeleteStudentAsync([FromBody] SingleStudent id)
        {
            var result = await _studentService.DeleteStudentAsync(id);
            return result;
        }

        [HttpPost("student/soft-delete-student")]
        public async Task<GeneralResponsePayload> SoftDeleteStudentAsync([FromBody] SingleStudent id)
        {
            var result = await _studentService.SoftDeleteStudentAsync(id);
            return result;
        }

        [HttpPost("student/year-summary")]
        public async Task<GeneralResponsePayload> GetStudentYearSummaryAsync([FromBody] RecordsByMonthDto id)
        {
            var result = await _studentService.GetStudentYearSummaryAsync(id);
            return result;
        }
    }
}

