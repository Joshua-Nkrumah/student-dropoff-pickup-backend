﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cleverchap_montessori.Controllers
{

    [Route("api/")]
    public class AttendanceController : ControllerBase
    {
        private readonly IAttendanceService _attendanceService;

        public AttendanceController(IAttendanceService attendanceService)
        {
            _attendanceService = attendanceService;
        }


        [HttpPost("attendance/get-all-attendances")]
        public async Task<GeneralResponsePayload> GetAllAttendanceAsync()
        {
            var result = await _attendanceService.GetAllAttendancesAsync();
            return result;
        }

        [HttpPost("attendance/year-summary")]
        public async Task<GeneralResponsePayload> GetAttendanceYearSummaryAsync([FromBody] RecordsByMonthDto id)
        {
            var result = await _attendanceService.GetAttendanceYearSummaryAsync(id);
            return result;
        }
    }
}

