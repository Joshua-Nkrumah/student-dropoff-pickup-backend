﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Class;
using cleverchap_montessori.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cleverchap_montessori.Controllers
{

    [Route("api/")]
    public class ClassController : ControllerBase
    {
        private readonly IClassService _classService;

        public ClassController(IClassService classService)
        {
            _classService = classService;
        }

        [HttpPost("class/create-class")]
        public async Task<GeneralResponsePayload> CreateClass([FromBody] AddClass payload)
        {
            var result = await _classService.CreateClassAsync(payload);
            return result;
        }

        [HttpPost("class/get-class")]
        public async Task<GeneralResponsePayload> GetClassByIdAsync([FromBody] SingleClass id)
        {
            var result = await _classService.GetClassByIdAsync(id);
            return result;
        }

        [HttpPost("class/get-all-classs")]
        public async Task<GeneralResponsePayload> GetAllClasssAsync()
        {
            var result = await _classService.GetAllClasssAsync();
            return result;
        }


        [HttpPost("class/update-class")]
        public async Task<GeneralResponsePayload> UpdateClassAsync([FromBody] UpdateClass updatedClass)
        {
            var result = await _classService.UpdateClassAsync(updatedClass);
            return result;
        }

        [HttpPost("class/delete-class")]
        public async Task<GeneralResponsePayload> DeleteClassAsync([FromBody] SingleClass id)
        {
            var result = await _classService.DeleteClassAsync(id);
            return result;
        }

        [HttpPost("class/soft-delete-class")]
        public async Task<GeneralResponsePayload> SoftDeleteClassAsync([FromBody] SingleClass id)
        {
            var result = await _classService.SoftDeleteClassAsync(id);
            return result;
        }

        [HttpPost("class/year-summary")]
        public async Task<GeneralResponsePayload> GetClassYearSummaryAsync([FromBody] RecordsByMonthDto id)
        {
            var result = await _classService.GetClassYearSummaryAsync(id);
            return result;
        }
    }
}

