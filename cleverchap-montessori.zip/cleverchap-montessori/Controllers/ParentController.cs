﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Payloads.Request.Parent;
using cleverchap_montessori.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cleverchap_montessori.Controllers
{
    [Route("api/")]
    public class ParentController : ControllerBase
    {
        private readonly IParentService _parentService;

        public ParentController(IParentService parentService)
        {
            _parentService = parentService;
        }

        [HttpPost("parent/create-parent")]
        public async Task<GeneralResponsePayload> CreateParent([FromBody] AddParent payload)
        {
            var result = await _parentService.CreateParentAsync(payload);
            return result;
        }

        [HttpPost("parent/get-parent")]
        public async Task<GeneralResponsePayload> GetParentByIdAsync([FromBody] SingleParent id)
        {
            var result = await _parentService.GetParentByIdAsync(id);
            return result;
        }

        [HttpPost("parent/get-all-parents")]
        public async Task<GeneralResponsePayload> GetAllParentsAsync()
        {
            var result = await _parentService.GetAllParentsAsync();
            return result;
        }


        [HttpPost("parent/update-parent")]
        public async Task<GeneralResponsePayload> UpdateParentAsync([FromBody] UpdateParent updatedParent)
        {
            var result = await _parentService.UpdateParentAsync(updatedParent);
            return result;
        }

        [HttpPost("parent/delete-parent")]
        public async Task<GeneralResponsePayload> DeleteParentAsync([FromBody] SingleParent id)
        {
            var result = await _parentService.DeleteParentAsync(id);
            return result;
        }

        [HttpPost("parent/soft-delete-parent")]
        public async Task<GeneralResponsePayload> SoftDeleteParentAsync([FromBody] SingleParent id)
        {
            var result = await _parentService.SoftDeleteParentAsync(id);
            return result;
        }

        [HttpPost("parent/year-summary")]
        public async Task<GeneralResponsePayload> GetParentYearSummaryAsync([FromBody] RecordsByMonthDto id)
        {
            var result = await _parentService.GetParentYearSummaryAsync(id);
            return result;
        }
    }

}

