﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request;
using cleverchap_montessori.Payloads.Request.Verification;
using cleverchap_montessori.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cleverchap_montessori.Controllers
{
    [Route("api/")]
    public class VerificationController : ControllerBase
    {
        private readonly IVerificationService _VerificationService;

        public VerificationController(IVerificationService VerificationService)
        {
            _VerificationService = VerificationService;
        }

        [HttpPost("verification/generate-otp")]
        public async Task<GeneralResponsePayload> GenerateCode([FromBody]  InitiateVerification Verification)
        {
            var result = await _VerificationService.GenerateCodeAsync(Verification);
            return result;
        }

        [HttpPost("verification/verify-otp")]
        public async Task<GeneralResponsePayload> VerifyCode([FromBody] AcceptVerificationCode Payload)
        {
            var result = await _VerificationService.VerifyCodeAsync(Payload);
            return result;
        }
    }
}

