﻿using cleverchap_montessori.Models;
using cleverchap_montessori.Payloads.Request.Delegate;
using cleverchap_montessori.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace cleverchap_montessori.Controllers
{

    [Route("api/")]
    public class DelegateController : ControllerBase
    {
        private readonly IDelegateService _delegateService;

        public DelegateController(IDelegateService delegateService)
        {
            _delegateService = delegateService;
        }

        [HttpPost("delegate/create-delegate")]
        public async Task<GeneralResponsePayload> CreateDelegate([FromBody] AddDelegate payload)
        {
            var result = await _delegateService.CreateDelegateAsync(payload);
            return result;
        }

        [HttpPost("delegate/get-delegate")]
        public async Task<GeneralResponsePayload> GetDelegateByIdAsync([FromBody] SingleDelegate id)
        {
            var result = await _delegateService.GetDelegateByIdAsync(id);
            return result;
        }

        [HttpPost("delegate/get-all-delegates")]
        public async Task<GeneralResponsePayload> GetAllDelegatesAsync()
        {
            var result = await _delegateService.GetAllDelegatesAsync();
            return result;
        }


        [HttpPost("delegate/update-delegate")]
        public async Task<GeneralResponsePayload> UpdateDelegateAsync([FromBody] UpdateDelegate updatedDelegate)
        {
            var result = await _delegateService.UpdateDelegateAsync(updatedDelegate);
            return result;
        }


        [HttpPost("delegate/delete-delegate")]
        public async Task<GeneralResponsePayload> DeleteDelegateAsync([FromBody] SingleDelegate id)
        {
            var result = await _delegateService.DeleteDelegateAsync(id);
            return result;
        }

        [HttpPost("delegate/soft-delete-delegate")]
        public async Task<GeneralResponsePayload> SoftDeleteDelegateAsync([FromBody] SingleDelegate id)
        {
            var result = await _delegateService.SoftDeleteDelegateAsync(id);
            return result;
        }

        [HttpPost("delegate/year-summary")]
        public async Task<GeneralResponsePayload> GetDelegateYearSummaryAsync([FromBody] RecordsByMonthDto id)
        {
            var result = await _delegateService.GetDelegateYearSummaryAsync(id);
            return result;
        }
    }

}

