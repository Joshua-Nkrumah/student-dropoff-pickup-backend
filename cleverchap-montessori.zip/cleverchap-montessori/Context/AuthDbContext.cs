﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using cleverchap_montessori.Models.Auth;
using cleverchap_montessori.Models.App;

namespace cleverchap_montessori.Context
{

    //public class AuthDbContext : IdentityDbContext<ApplicationUser>
    //{
    //    public AuthDbContext(DbContextOptions<AuthDbContext> options) : base(options)
    //    {

    //    }
    //    public DbSet<User> User { get; set; }
    //    //public DbSet<cleverchap_montessoriGroup> cleverchap_montessoriGroup { get; set; }
    //    //public DbSet<Member> Members { get; set; }
    //    //public DbSet<Contribution> Contributions { get; set; }
    //    //public DbSet<Volunteer> Volunteers { get; set; }
    //    //public DbSet<Donation> Donations { get; set; }
    //}

    public class AuthDbContext : IdentityDbContext<ApplicationUser>
    {
        public AuthDbContext(DbContextOptions<AuthDbContext> options)
            : base(options)
        { }

        public DbSet<User> User { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
        }
    }


    //public class AuthDbContext : IdentityDbContext<ApplicationUser>
    //{
    //    public AuthDbContext(DbContextOptions<AuthDbContext> options)
    //        : base(options)
    //    {
    //    }

    //    protected override void OnModelCreating(ModelBuilder builder)
    //    {
    //        base.OnModelCreating(builder);
    //        // Customize the ASP.NET Identity model and override the defaults if needed.
    //        // For example, you can rename the ASP.NET Identity table names and more.
    //        // Add your customizations after calling base.OnModelCreating(builder);
    //    }
    //}
}

