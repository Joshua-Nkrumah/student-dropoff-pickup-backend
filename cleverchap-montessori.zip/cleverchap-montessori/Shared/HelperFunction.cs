﻿using System;
using System.Security.Cryptography;
using System.Text;
using cleverchap_montessori.Settings;

namespace cleverchap_montessori.Shared
{

    using System;
    using System.Text;
    using Microsoft.AspNetCore.Identity;

    public class PasswordGenerator
    {
        private const string LowercaseCharacters = "abcdefghijklmnopqrstuvwxyz";
        private const string UppercaseCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private const string NumericCharacters = "0123456789";
        private const string SpecialCharacters = "!@#$%^&*()-_+=<>?";

        public static string GenerateRandomPassword(int length, bool includeUppercase, bool includeNumeric, bool includeSpecial)
        {
            string characters = LowercaseCharacters;

            if (includeUppercase)
            {
                characters += UppercaseCharacters;
            }

            if (includeNumeric)
            {
                characters += NumericCharacters;
            }

            if (includeSpecial)
            {
                characters += SpecialCharacters;
            }

            Random random = new Random();
            StringBuilder password = new StringBuilder();

            for (int i = 0; i < length; i++)
            {
                int index = random.Next(characters.Length);
                password.Append(characters[index]);
            }

            return password.ToString();
        }

        public static string GenerateValidPassword()
        {
            int minLength = 9;
            int maxLength = 15;
            // Create a new StringBuilder object to store the password.
            StringBuilder passwordBuilder = new StringBuilder();

            // Create a new Random object to generate random characters.
            Random random = new Random();

            // Add random characters to the password builder until the
            // specified minimum length is reached.
            for (int i = 0; i < minLength; i++)
            {
                passwordBuilder.Append(random.Next('A', 'Z'));
                passwordBuilder.Append(random.Next('a', 'z'));
                passwordBuilder.Append(random.Next('0', '9'));
                passwordBuilder.Append(random.Next('!', '@'));
            }

            // Truncate the password to the specified maximum length.
            passwordBuilder.Length = Math.Min(maxLength, passwordBuilder.Length);

            // Return the generated password.
            return passwordBuilder.ToString();
        }

        public static string GeneratePassword(int length = 12)
        {
            // Create a new Random object.
            var random = new RNGCryptoServiceProvider();

            // Create a new byte array to store the password.
            var bytes = new byte[length];

            // Fill the byte array with random bytes.
            random.GetBytes(bytes);

            // Convert the byte array to a string using the Base64 encoding.
            return Convert.ToBase64String(bytes);
        }

        //public static string GeneratePassword(int length = 12)
        //{
        //    const string validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()_-+=<>?";
        //    var random = new RNGCryptoServiceProvider();
        //    var bytes = new byte[length];
        //    random.GetBytes(bytes);

        //    var password = new StringBuilder(length);
        //    foreach (byte b in bytes)
        //    {
        //        password.Append(validChars[b % (validChars.Length)]);
        //    }

        //    return password.ToString();
        //}
    }

    


    public class HelperFunction
	{

        public static string ComputeSha256Hash(string rawData)
        {
            // Create a SHA256   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static AppSettings GetAppSettingsData()
        {
            IConfigurationRoot configuration = new ConfigurationBuilder().SetBasePath(AppDomain.CurrentDomain.BaseDirectory).AddJsonFile("appsettings.json").Build();
            return configuration.Get<AppSettings>();
        }


        public static string formatedphone(string phoneNum)

        {

            phoneNum = phoneNum.Trim();

            if (phoneNum.StartsWith("0") && phoneNum.Length == 10)

            {

                phoneNum = phoneNum.Remove(0, 1);

                phoneNum = "233" + phoneNum;

            }

            else if (!phoneNum.StartsWith("0") && phoneNum.Length == 9)

            {

                //phoneNum = phoneNum.Remove(0, 1);

                phoneNum = "233" + phoneNum;

            }

            else if (phoneNum.StartsWith("+233"))

            {

                phoneNum = phoneNum.Remove(0, 1);

            }

            else if (phoneNum.StartsWith("2330") && phoneNum.Length == 13)

            {

                phoneNum = phoneNum.Remove(0, 4);

                phoneNum = "233" + phoneNum;

            }

            else if (phoneNum.StartsWith("00233") && phoneNum.Length == 14)

            {

                //00233244379052

                phoneNum = phoneNum.Remove(0, 5);

                phoneNum = "233" + phoneNum;

            }

            else if (phoneNum.StartsWith("0233") && phoneNum.Length == 13)

            {

                //00233244379052

                phoneNum = phoneNum.Remove(0, 4);

                phoneNum = "233" + phoneNum;

            }

            else if (phoneNum.StartsWith("233"))

            {

                //phoneNum = "+" + phoneNum;

            }

            else if (phoneNum.StartsWith("+"))

            {

                phoneNum = phoneNum.Remove(0, 1);

            }

            phoneNum = phoneNum.Replace(" ", "");



            return phoneNum.Trim();

        }
    }
}

