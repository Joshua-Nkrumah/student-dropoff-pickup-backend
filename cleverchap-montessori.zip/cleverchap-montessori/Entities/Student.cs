﻿using System;
using System.Collections.Generic;

namespace cleverchap_montessori.Entities;

public partial class Student
{
    public Guid StudentId { get; set; }

    public string? ClassId { get; set; }

    public string? StudentNumber { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? DateOfBirth { get; set; }

    public string? Gender { get; set; }

    public string? Status { get; set; }

    public string? EmergencyContact { get; set; }

    public string? Location { get; set; }

    public string? Nationality { get; set; }

    public string? CreatedBy { get; set; }

    public string? MedicalConditions { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
