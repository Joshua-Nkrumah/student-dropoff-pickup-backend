﻿using System;
using System.Collections.Generic;

namespace cleverchap_montessori.Entities;

public partial class PickupDropoffLog
{
    public Guid LogId { get; set; }

    public string? StudentId { get; set; }

    public string? ParentId { get; set; }

    public string? DelegateId { get; set; }

    public string? ClassId { get; set; }

    public string? ActivityType { get; set; }

    /// <summary>
    /// Whether is it Drop Off or PickUp
    /// </summary>
    public DateTime? AuthorizedDateTime { get; set; }

    public string? AuthorizedName { get; set; }

    public string? Relation { get; set; }

    public string? Remarks { get; set; }

    public string? Status { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
