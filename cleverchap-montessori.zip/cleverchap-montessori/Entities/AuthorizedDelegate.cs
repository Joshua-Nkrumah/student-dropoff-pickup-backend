﻿using System;
using System.Collections.Generic;

namespace cleverchap_montessori.Entities;

public partial class AuthorizedDelegate
{
    public Guid DelegateId { get; set; }

    public string? StudentId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Status { get; set; }

    public string? Email { get; set; }

    public string? Phone { get; set; }

    public string? RelationshipToChild { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
