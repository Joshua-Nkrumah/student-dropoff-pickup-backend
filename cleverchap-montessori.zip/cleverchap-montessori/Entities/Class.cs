﻿using System;
using System.Collections.Generic;

namespace cleverchap_montessori.Entities;

public partial class Class
{
    public Guid ClassId { get; set; }

    public Guid? TeacherId { get; set; }

    public string? ClassName { get; set; }

    public string? Description { get; set; }

    public string? Status { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
