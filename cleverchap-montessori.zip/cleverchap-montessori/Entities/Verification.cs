﻿using System;
using System.Collections.Generic;

namespace cleverchap_montessori.Entities;

public partial class Verification
{
    public Guid VerificationId { get; set; }

    public string? LogId { get; set; }

    public string? Otp { get; set; }

    public DateTime? ExpiryTime { get; set; }

    public string? Status { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }
}
